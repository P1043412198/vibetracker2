import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../services/photo_storage.dart';

/// Matches a GitHub-style task list line: optional indent, `- [ ]`/`- [x]`,
/// then the label. Group 1 = indent, group 2 = check char, group 3 = label.
final RegExp articleTaskLine = RegExp(r'^(\s*)[-*]\s\[([ xX])\]\s?(.*)$');

/// Matches an inline Markdown image `![alt](src)`. Group 1 = src.
final RegExp articleInlineImage = RegExp(r'!\[[^\]]*\]\(([^)\s]+)\)');

/// Toggles `- [ ]` ↔ `- [x]` on [lineIndex]. Returns the new source text or
/// `null` when that line is not a task item.
String? toggleArticleTaskLine(String source, int lineIndex) {
  final lines = source.split('\n');
  if (lineIndex < 0 || lineIndex >= lines.length) return null;
  final m = articleTaskLine.firstMatch(lines[lineIndex]);
  if (m == null) return null;
  final done = m.group(2)!.toLowerCase() == 'x';
  lines[lineIndex] = '${m.group(1)}- [${done ? ' ' : 'x'}] ${m.group(3)}';
  return lines.join('\n');
}

/// Local (non-http) image paths embedded in [source] — used to clean up
/// stored files when an article/note is deleted.
List<String> articleLocalImages(String source) {
  return [
    for (final m in articleInlineImage.allMatches(source))
      if (!m.group(1)!.startsWith('http')) m.group(1)!,
  ];
}

/// Полноценная панель форматирования для статей: заголовки, списки,
/// чек-боксы, цитаты, код, разделители, ссылки и картинки.
class ArticleMarkdownToolbar extends StatelessWidget {
  const ArticleMarkdownToolbar({
    super.key,
    required this.controller,
    this.onPickImage,
  });

  final TextEditingController controller;

  /// Returns a stored image path (relative) or URL to embed, or null.
  final Future<String?> Function()? onPickImage;

  void _insert(String snippet, {bool atLineStart = false}) {
    final text = controller.text;
    final sel = controller.selection;
    var start = sel.start < 0 ? text.length : sel.start;
    var end = sel.end < 0 ? text.length : sel.end;
    if (atLineStart) {
      final lineStart = text.lastIndexOf('\n', start - 1) + 1;
      start = lineStart;
      end = lineStart;
    }
    final next = text.replaceRange(start, end, snippet);
    controller.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: start + snippet.length),
    );
  }

  void _wrap(String marker) {
    final text = controller.text;
    final sel = controller.selection;
    if (sel.start < 0 || sel.end < 0 || sel.start == sel.end) {
      _insert('$marker$marker');
      final pos = controller.selection.start - marker.length;
      controller.selection = TextSelection.collapsed(offset: pos);
      return;
    }
    final selected = text.substring(sel.start, sel.end);
    final next =
        text.replaceRange(sel.start, sel.end, '$marker$selected$marker');
    controller.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: sel.end + marker.length * 2),
    );
  }

  Future<void> _insertLink(BuildContext context) async {
    final label = TextEditingController();
    final url = TextEditingController(text: 'https://');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Вставить ссылку'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: label,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Текст'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: url,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(labelText: 'URL'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Вставить')),
        ],
      ),
    );
    if (ok == true) {
      final u = url.text.trim();
      if (u.isNotEmpty && u != 'https://') {
        final t = label.text.trim();
        _insert('[${t.isEmpty ? u : t}]($u)');
      }
    }
    label.dispose();
    url.dispose();
  }

  Future<void> _insertImage() async {
    final path = await onPickImage?.call();
    if (path == null || path.isEmpty) return;
    _insert('\n![фото]($path)\n');
  }

  @override
  Widget build(BuildContext context) {
    Widget btn(IconData icon, String tip, VoidCallback onTap) => IconButton(
          visualDensity: VisualDensity.compact,
          tooltip: tip,
          icon: Icon(icon, size: 20),
          onPressed: onTap,
        );
    return Align(
      alignment: Alignment.centerLeft,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            btn(Icons.title, 'Заголовок',
                () => _insert('## ', atLineStart: true)),
            btn(Icons.format_bold, 'Жирный', () => _wrap('**')),
            btn(Icons.format_italic, 'Курсив', () => _wrap('*')),
            btn(Icons.format_strikethrough, 'Зачёркнутый',
                () => _wrap('~~')),
            btn(Icons.format_list_bulleted, 'Список',
                () => _insert('- ', atLineStart: true)),
            btn(Icons.format_list_numbered, 'Нумерованный',
                () => _insert('1. ', atLineStart: true)),
            btn(Icons.checklist, 'Чек-пункт',
                () => _insert('- [ ] ', atLineStart: true)),
            btn(Icons.format_quote, 'Цитата',
                () => _insert('> ', atLineStart: true)),
            btn(Icons.code, 'Код', () => _wrap('`')),
            btn(Icons.horizontal_rule, 'Разделитель',
                () => _insert('\n---\n')),
            btn(Icons.link, 'Ссылка', () => _insertLink(context)),
            if (onPickImage != null)
              btn(Icons.image_outlined, 'Картинка', _insertImage),
          ],
        ),
      ),
    );
  }
}

/// Renders article Markdown with tappable checkboxes, external links and
/// inline images (both network URLs and locally stored photos).
class ArticleMarkdownView extends StatelessWidget {
  const ArticleMarkdownView({
    super.key,
    required this.text,
    required this.accent,
    this.onToggleTask,
    this.emptyPlaceholder,
  });

  final String text;
  final Color accent;
  final void Function(int lineIndex)? onToggleTask;
  final String? emptyPlaceholder;

  void _openLink(String? href) {
    if (href == null) return;
    final uri = Uri.tryParse(href);
    if (uri != null) launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Widget _image(BuildContext context, Uri uri) {
    final src = Uri.decodeFull(uri.toString());
    final broken = Container(
      padding: const EdgeInsets.symmetric(vertical: 20),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Icon(Icons.broken_image_outlined),
    );
    final img = src.startsWith('http')
        ? Image.network(src,
            fit: BoxFit.cover, errorBuilder: (_, __, ___) => broken)
        : Image.file(File(PhotoStorage.instance.resolve(src)),
            fit: BoxFit.cover, errorBuilder: (_, __, ___) => broken);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: img,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (text.trim().isEmpty) {
      return Text(
        emptyPlaceholder ??
            'Пусто — нажмите «Редактировать», чтобы начать писать.',
        style: TextStyle(color: Theme.of(context).colorScheme.outline),
      );
    }

    final styleSheet =
        MarkdownStyleSheet.fromTheme(Theme.of(context)).copyWith(
      p: const TextStyle(fontSize: 16, height: 1.5),
      blockquoteDecoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        border: Border(left: BorderSide(color: accent, width: 3)),
      ),
    );

    final lines = text.split('\n');
    final children = <Widget>[];
    final buffer = <String>[];

    void flushBuffer() {
      if (buffer.isEmpty) return;
      children.add(MarkdownBody(
        data: buffer.join('\n'),
        selectable: true,
        styleSheet: styleSheet,
        onTapLink: (_, href, __) => _openLink(href),
        imageBuilder: (uri, _, __) => _image(context, uri),
      ));
      buffer.clear();
    }

    for (var i = 0; i < lines.length; i++) {
      final m = articleTaskLine.firstMatch(lines[i]);
      if (m == null) {
        buffer.add(lines[i]);
        continue;
      }
      flushBuffer();
      final done = m.group(2)!.toLowerCase() == 'x';
      final label = m.group(3) ?? '';
      final idx = i;
      children.add(
        InkWell(
          onTap: onToggleTask == null ? null : () => onToggleTask!(idx),
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  done ? Icons.check_box : Icons.check_box_outline_blank,
                  size: 22,
                  color:
                      done ? accent : Theme.of(context).colorScheme.outline,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: MarkdownBody(
                      data: label.isEmpty ? '\u200b' : label,
                      selectable: false,
                      styleSheet: styleSheet.copyWith(
                        p: TextStyle(
                          fontSize: 16,
                          height: 1.4,
                          decoration:
                              done ? TextDecoration.lineThrough : null,
                          color: done
                              ? Theme.of(context).colorScheme.outline
                              : null,
                        ),
                      ),
                      onTapLink: (_, href, __) => _openLink(href),
                      imageBuilder: (uri, _, __) => _image(context, uri),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }
    flushBuffer();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: children,
    );
  }
}
