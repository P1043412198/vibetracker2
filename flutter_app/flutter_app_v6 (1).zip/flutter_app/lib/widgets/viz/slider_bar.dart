import 'package:flutter/material.dart';

/// Read-only slider-style indicator: a gradient track with a thumb at the
/// current value, an optional target tick and min/max labels. Use it when a
/// value lives on a scale (0 → goal, min → max) and you want the position to
/// be instantly readable.
class ValueSliderBar extends StatelessWidget {
  const ValueSliderBar({
    super.key,
    required this.value,
    required this.max,
    this.min = 0,
    this.target,
    this.color,
    this.height = 12,
    this.minLabel,
    this.maxLabel,
    this.valueLabel,
  });

  final double value;
  final double min;
  final double max;

  /// Optional target within [min, max]; rendered as a tick on the track.
  final double? target;
  final Color? color;
  final double height;
  final String? minLabel;
  final String? maxLabel;

  /// Optional label rendered above the thumb (e.g. "1250 мл").
  final String? valueLabel;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final c = color ?? scheme.primary;
    final span = (max - min) == 0 ? 1.0 : (max - min);
    final frac = ((value - min) / span).clamp(0.0, 1.0);
    final targetFrac =
        target == null ? null : ((target! - min) / span).clamp(0.0, 1.0);
    const thumbSize = 20.0;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: thumbSize + (valueLabel != null ? 18 : 0),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final w = constraints.maxWidth;
              return TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: frac),
                duration: const Duration(milliseconds: 600),
                curve: Curves.easeOutCubic,
                builder: (context, f, _) {
                  final thumbX =
                      (f * w - thumbSize / 2).clamp(0.0, w - thumbSize);
                  return Stack(
                    clipBehavior: Clip.none,
                    children: [
                      // Track
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: (thumbSize - height) / 2,
                        child: Container(
                          height: height,
                          decoration: BoxDecoration(
                            color: scheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(height / 2),
                          ),
                        ),
                      ),
                      // Fill
                      Positioned(
                        left: 0,
                        width: (f * w).clamp(height, w),
                        bottom: (thumbSize - height) / 2,
                        child: Container(
                          height: height,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [c.withValues(alpha: 0.45), c],
                            ),
                            borderRadius: BorderRadius.circular(height / 2),
                          ),
                        ),
                      ),
                      // Target tick
                      if (targetFrac != null)
                        Positioned(
                          left: (targetFrac * w - 1).clamp(0.0, w - 2),
                          bottom: (thumbSize - height) / 2 - 2,
                          child: Container(
                            width: 2,
                            height: height + 4,
                            color: scheme.outline,
                          ),
                        ),
                      // Thumb
                      Positioned(
                        left: thumbX,
                        bottom: 0,
                        child: Container(
                          width: thumbSize,
                          height: thumbSize,
                          decoration: BoxDecoration(
                            color: c,
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: scheme.surface, width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: c.withValues(alpha: 0.45),
                                blurRadius: 8,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                        ),
                      ),
                      // Value label above the thumb
                      if (valueLabel != null)
                        Positioned(
                          left: (thumbX - 30).clamp(0.0, w - 60),
                          bottom: thumbSize + 1,
                          child: SizedBox(
                            width: 60,
                            child: Text(
                              valueLabel!,
                              textAlign: TextAlign.center,
                              maxLines: 1,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                color: c,
                              ),
                            ),
                          ),
                        ),
                    ],
                  );
                },
              );
            },
          ),
        ),
        if (minLabel != null || maxLabel != null)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(minLabel ?? '',
                    style: Theme.of(context).textTheme.labelSmall),
                Text(maxLabel ?? '',
                    style: Theme.of(context).textTheme.labelSmall),
              ],
            ),
          ),
      ],
    );
  }
}
