/// Shared visualisation primitives used across finance and workouts.
///
/// A single, consistent visual language: semantic colours ([heatColor],
/// [vizStatusColor]) plus reusable widgets so metrics look and behave the same
/// everywhere.
library;

export 'activity_rings.dart';
export 'animated_number.dart';
export 'bullet_bar.dart';
export 'configurable_viz.dart';
export 'donut_chart.dart';
export 'heat_calendar.dart';
export 'heat_color.dart';
export 'mini_bar_chart.dart';
export 'progress_ring.dart';
export 'radar_chart.dart';
export 'radial_gauge.dart';
export 'segmented_bar.dart';
export 'slider_bar.dart';
export 'sparkline.dart';
export 'split_bar.dart';
export 'status_hero.dart';
export 'trend_delta.dart';
