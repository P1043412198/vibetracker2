import 'dart:math' as math;

import 'package:flutter/material.dart';

/// One slice of a [DonutChart].
class DonutSegment {
  const DonutSegment({
    required this.value,
    required this.color,
    this.label,
  });

  final double value;
  final Color color;
  final String? label;
}

/// Lightweight animated donut chart drawn with a stroke arc per segment.
/// Put a total or an icon in the middle via [center]/[centerLabel].
class DonutChart extends StatelessWidget {
  const DonutChart({
    super.key,
    required this.segments,
    this.size = 110,
    this.thickness = 18,
    this.center,
    this.centerLabel,
    this.gapDegrees = 2,
  });

  final List<DonutSegment> segments;
  final double size;
  final double thickness;
  final String? center;
  final String? centerLabel;

  /// Visual gap between slices, in degrees.
  final double gapDegrees;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 800),
      curve: Curves.easeOutCubic,
      builder: (context, t, _) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _DonutPainter(
            segments: segments,
            t: t,
            thickness: thickness,
            gapRadians: gapDegrees * math.pi / 180,
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (center != null)
                  Text(
                    center!,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: size / 6,
                    ),
                  ),
                if (centerLabel != null)
                  Text(
                    centerLabel!,
                    style: Theme.of(context).textTheme.labelSmall,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DonutPainter extends CustomPainter {
  _DonutPainter({
    required this.segments,
    required this.t,
    required this.thickness,
    required this.gapRadians,
  });

  final List<DonutSegment> segments;
  final double t;
  final double thickness;
  final double gapRadians;

  @override
  void paint(Canvas canvas, Size size) {
    final visible = segments.where((s) => s.value > 0).toList();
    if (visible.isEmpty) return;
    final total = visible.fold<double>(0, (a, s) => a + s.value);
    if (total <= 0) return;
    final center = (Offset.zero & size).center;
    final radius = (size.shortestSide - thickness) / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);
    final gap = visible.length > 1 ? gapRadians : 0.0;
    var start = -math.pi / 2;
    for (final s in visible) {
      final sweep =
          math.max(0.0, (s.value / total) * 2 * math.pi * t - gap);
      if (sweep > 0) {
        canvas.drawArc(
          rect,
          start + gap / 2,
          sweep,
          false,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = thickness
            ..strokeCap = StrokeCap.butt
            ..color = s.color,
        );
      }
      start += (s.value / total) * 2 * math.pi * t;
    }
  }

  @override
  bool shouldRepaint(covariant _DonutPainter old) =>
      old.t != t ||
      old.segments != segments ||
      old.thickness != thickness ||
      old.gapRadians != gapRadians;
}

/// Compact legend to place next to a [DonutChart].
class DonutLegend extends StatelessWidget {
  const DonutLegend({super.key, required this.segments, this.valueBuilder});

  final List<DonutSegment> segments;

  /// Formats the trailing value. Defaults to the raw number.
  final String Function(DonutSegment segment)? valueBuilder;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final s in segments)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: s.color,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    s.label ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Text(
                  valueBuilder?.call(s) ??
                      (s.value == s.value.roundToDouble()
                          ? s.value.toInt().toString()
                          : s.value.toStringAsFixed(1)),
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
