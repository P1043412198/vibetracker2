import 'dart:math' as math;

import 'package:flutter/material.dart';

/// One ring of an [ActivityRings] stack.
class ActivityRingData {
  const ActivityRingData({required this.progress, required this.color});

  /// 0..1 (clamped).
  final double progress;
  final Color color;
}

/// Apple-Watch-style concentric activity rings. Each ring is an independent
/// metric; the whole stack animates in together.
class ActivityRings extends StatelessWidget {
  const ActivityRings({
    super.key,
    required this.rings,
    this.size = 120,
    this.strokeWidth = 10,
    this.gap = 3,
    this.child,
  });

  /// Outermost ring first.
  final List<ActivityRingData> rings;
  final double size;
  final double strokeWidth;
  final double gap;

  /// Optional widget in the middle (e.g. a total or an icon).
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 850),
      curve: Curves.easeOutCubic,
      builder: (context, t, _) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _ActivityRingsPainter(
            rings: rings,
            t: t,
            strokeWidth: strokeWidth,
            gap: gap,
          ),
          child: child == null ? null : Center(child: child),
        ),
      ),
    );
  }
}

class _ActivityRingsPainter extends CustomPainter {
  _ActivityRingsPainter({
    required this.rings,
    required this.t,
    required this.strokeWidth,
    required this.gap,
  });

  final List<ActivityRingData> rings;
  final double t;
  final double strokeWidth;
  final double gap;

  @override
  void paint(Canvas canvas, Size size) {
    final center = (Offset.zero & size).center;
    var radius = (size.shortestSide - strokeWidth) / 2;
    for (final ring in rings) {
      if (radius <= 0) break;
      final rect = Rect.fromCircle(center: center, radius: radius);
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = strokeWidth
          ..color = ring.color.withValues(alpha: 0.16),
      );
      final sweep = 2 * math.pi * (ring.progress.clamp(0.0, 1.0)) * t;
      if (sweep > 0) {
        canvas.drawArc(
          rect,
          -math.pi / 2,
          sweep,
          false,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = strokeWidth
            ..strokeCap = StrokeCap.round
            ..color = ring.color,
        );
      }
      radius -= strokeWidth + gap;
    }
  }

  @override
  bool shouldRepaint(covariant _ActivityRingsPainter old) =>
      old.t != t ||
      old.rings != rings ||
      old.strokeWidth != strokeWidth ||
      old.gap != gap;
}
