import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../state/viz_prefs_state.dart';
import 'activity_rings.dart';
import 'donut_chart.dart';
import 'mini_bar_chart.dart';
import 'progress_ring.dart';
import 'radial_gauge.dart';
import 'segmented_bar.dart';
import 'slider_bar.dart';
import 'sparkline.dart';

/// Способы отображения одной и той же метрики. Пользователь выбирает
/// стиль в пикере [ConfigurableViz]; выбор сохраняется на устройстве.
enum VizStyle {
  ring,
  rings,
  donut,
  bars,
  segmented,
  slider,
  linear,
  gauge,
  sparkline;

  String get labelRu => switch (this) {
        VizStyle.ring => 'Кольцо',
        VizStyle.rings => 'Кольца',
        VizStyle.donut => 'Донат',
        VizStyle.bars => 'Столбики',
        VizStyle.segmented => 'Сегменты',
        VizStyle.slider => 'Слайдер',
        VizStyle.linear => 'Полоса',
        VizStyle.gauge => 'Шкала',
        VizStyle.sparkline => 'Тренд',
      };

  IconData get icon => switch (this) {
        VizStyle.ring => Icons.data_usage,
        VizStyle.rings => Icons.track_changes,
        VizStyle.donut => Icons.donut_large,
        VizStyle.bars => Icons.bar_chart,
        VizStyle.segmented => Icons.view_week,
        VizStyle.slider => Icons.linear_scale,
        VizStyle.linear => Icons.horizontal_rule,
        VizStyle.gauge => Icons.speed,
        VizStyle.sparkline => Icons.show_chart,
      };
}

/// Данные метрики для [ConfigurableViz]. Обязателен только [progress];
/// остальные поля расширяют набор доступных стилей (например,
/// [series] включает «Столбики» и «Тренд»).
class VizMetric {
  const VizMetric({
    required this.progress,
    this.color,
    this.centerText,
    this.caption,
    this.rings,
    this.segments,
    this.series,
    this.seriesLabels,
    this.referenceValue,
    this.highlightIndex,
    this.value,
    this.min = 0,
    this.max,
    this.valueLabel,
    this.minLabel,
    this.maxLabel,
    this.segmentCount = 10,
  });

  /// 0..1 — основной прогресс.
  final double progress;
  final Color? color;

  /// Текст в центре круговых виджетов (например «72%» или «5/8»).
  final String? centerText;

  /// Подпись под линейными стилями.
  final String? caption;

  /// Для стиля «Кольца»: несколько независимых метрик.
  final List<ActivityRingData>? rings;

  /// Для стиля «Донат»: явные сектора (иначе — готово/осталось).
  final List<DonutSegment>? segments;

  /// Для стилей «Столбики» и «Тренд»: ряд значений во времени.
  final List<double>? series;
  final List<String>? seriesLabels;
  final double? referenceValue;
  final int? highlightIndex;

  /// Для стиля «Слайдер»: абсолютное значение на шкале [min, max].
  final double? value;
  final double min;
  final double? max;
  final String? valueLabel;
  final String? minLabel;
  final String? maxLabel;

  /// Для стиля «Сегменты»: число делений.
  final int segmentCount;
}

/// Универсальный настраиваемый блок визуализации.
///
/// Одна метрика — много способов отображения. Пользователь сам
/// выбирает стиль (кнопка-тюнер в заголовке или долгое нажатие в
/// компактном режиме), выбор сохраняется по [prefKey].
class ConfigurableViz extends ConsumerWidget {
  const ConfigurableViz({
    super.key,
    required this.prefKey,
    required this.metric,
    this.styles = VizStyle.values,
    this.defaultStyle = VizStyle.ring,
    this.title,
    this.compact = false,
    this.size = 96,
  });

  /// Стабильный ключ блока, например `water.header`.
  final String prefKey;
  final VizMetric metric;

  /// Какие стили предлагать в пикере.
  final List<VizStyle> styles;
  final VizStyle defaultStyle;

  /// Заголовок блока (с кнопкой смены стиля). Игнорируется в [compact].
  final String? title;

  /// Без шапки; смена стиля — долгим нажатием.
  final bool compact;

  /// Диаметр круговых стилей / масштаб линейных.
  final double size;

  List<VizStyle> _available() {
    final hasSeries = metric.series != null && metric.series!.length >= 2;
    return [
      for (final s in styles)
        if (s != VizStyle.bars && s != VizStyle.sparkline || hasSeries) s,
    ];
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final available = _available();
    final storedName = ref.watch(vizPrefsProvider)[prefKey];
    var style = VizStyle.values.firstWhere(
      (s) => s.name == storedName,
      orElse: () => defaultStyle,
    );
    if (!available.contains(style)) {
      style = available.isEmpty ? defaultStyle : available.first;
    }
    final viz = _buildViz(context, style);

    if (compact) {
      // Долгое нажатие открывает выбор стиля.
      return GestureDetector(
        onLongPress: () => _openPicker(context, ref, style, available),
        child: viz,
      );
    }

    final scheme = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            if (title != null)
              Expanded(
                child: Text(
                  title!,
                  style: Theme.of(context).textTheme.titleSmall,
                ),
              )
            else
              const Spacer(),
            Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () => _openPicker(context, ref, style, available),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(style.icon,
                          size: 14, color: scheme.onSurfaceVariant),
                      const SizedBox(width: 4),
                      Icon(Icons.tune,
                          size: 14, color: scheme.onSurfaceVariant),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        viz,
      ],
    );
  }

  Widget _buildViz(BuildContext context, VizStyle style) {
    final scheme = Theme.of(context).colorScheme;
    final color = metric.color ?? scheme.primary;
    final p = metric.progress.clamp(0.0, 1.0);

    switch (style) {
      case VizStyle.ring:
        return AnimatedProgressRing(
          progress: p,
          color: color,
          size: size,
          strokeWidth: (size / 10).clamp(4.0, 12.0),
          center: metric.centerText,
          label: compact ? null : metric.caption,
        );
      case VizStyle.gauge:
        return RadialGauge(
          progress: p,
          label: compact ? '' : (metric.caption ?? ''),
          center: metric.centerText,
          color: color,
          size: size,
          strokeWidth: (size / 11).clamp(4.0, 11.0),
        );
      case VizStyle.rings:
        final rings = metric.rings ??
            [ActivityRingData(progress: p, color: color)];
        return ActivityRings(
          rings: rings,
          size: size,
          strokeWidth: (size / 10).clamp(4.0, 11.0),
          child: metric.centerText == null
              ? null
              : Text(
                  metric.centerText!,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: size / 6,
                  ),
                ),
        );
      case VizStyle.donut:
        final segments = metric.segments ??
            [
              DonutSegment(value: p, color: color, label: 'Готово'),
              DonutSegment(
                value: (1 - p).clamp(0.0, 1.0),
                color: scheme.surfaceContainerHighest,
                label: 'Осталось',
              ),
            ];
        final chart = DonutChart(
          segments: segments,
          size: size,
          thickness: (size / 6.5).clamp(8.0, 20.0),
          center: metric.centerText,
        );
        if (compact || metric.segments == null) return chart;
        return Row(
          children: [
            chart,
            const SizedBox(width: 12),
            Expanded(child: DonutLegend(segments: segments)),
          ],
        );
      case VizStyle.bars:
        return MiniBarChart(
          values: metric.series ?? const [],
          labels: metric.seriesLabels,
          height: size * 0.6,
          color: color,
          referenceValue: metric.referenceValue,
          highlightIndex: metric.highlightIndex,
        );
      case VizStyle.sparkline:
        return Sparkline(
          values: metric.series ?? const [],
          color: color,
          width: double.infinity,
          height: size * 0.45,
          strokeWidth: 2.2,
        );
      case VizStyle.segmented:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            SegmentedProgressBar(
              progress: p,
              segments: metric.segmentCount,
              height: (size / 8).clamp(8.0, 14.0),
              color: color,
            ),
            if (!compact && metric.caption != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(metric.caption!,
                    style: Theme.of(context).textTheme.labelSmall),
              ),
          ],
        );
      case VizStyle.slider:
        return ValueSliderBar(
          value: metric.value ?? p,
          min: metric.min,
          max: metric.max ?? 1,
          color: color,
          valueLabel: metric.valueLabel ?? metric.centerText,
          minLabel: metric.minLabel,
          maxLabel: metric.maxLabel,
        );
      case VizStyle.linear:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: p,
                minHeight: (size / 9).clamp(8.0, 12.0),
                color: color,
                backgroundColor: scheme.surfaceContainerHighest,
              ),
            ),
            if (!compact && metric.caption != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(metric.caption!,
                    style: Theme.of(context).textTheme.labelSmall),
              ),
          ],
        );
    }
  }

  void _openPicker(
    BuildContext context,
    WidgetRef ref,
    VizStyle current,
    List<VizStyle> available,
  ) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Вид визуализации',
                    style: Theme.of(sheetContext).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Выбери, как отображать этот показатель. Выбор сохранится.',
                  style: Theme.of(sheetContext).textTheme.bodySmall,
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final s in available)
                      ChoiceChip(
                        avatar: Icon(s.icon, size: 16),
                        label: Text(s.labelRu),
                        selected: s == current,
                        onSelected: (_) {
                          ref
                              .read(vizPrefsProvider.notifier)
                              .setStyle(prefKey, s.name);
                          Navigator.of(sheetContext).pop();
                        },
                      ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
