import 'package:flutter/material.dart';

/// Progress bar split into discrete segments ("battery" style). Great when
/// the goal is naturally chunked: cups of water, steps of a goal, weeks of a
/// challenge.
class SegmentedProgressBar extends StatelessWidget {
  const SegmentedProgressBar({
    super.key,
    required this.progress,
    this.segments = 10,
    this.height = 10,
    this.spacing = 3,
    this.color,
  });

  /// 0..1 (clamped).
  final double progress;
  final int segments;
  final double height;
  final double spacing;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final c = color ?? scheme.primary;
    final n = segments < 1 ? 1 : segments;
    final target = progress.clamp(0.0, 1.0);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: target),
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeOutCubic,
      builder: (context, p, _) {
        final filled = p * n;
        return Row(
          children: [
            for (var i = 0; i < n; i++) ...[
              if (i > 0) SizedBox(width: spacing),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(height / 2),
                  child: SizedBox(
                    height: height,
                    child: Stack(
                      children: [
                        Container(color: scheme.surfaceContainerHighest),
                        FractionallySizedBox(
                          widthFactor: (filled - i).clamp(0.0, 1.0),
                          child: Container(color: c),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}
