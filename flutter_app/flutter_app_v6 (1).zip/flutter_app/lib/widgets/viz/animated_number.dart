import 'package:flutter/material.dart';

/// Плавно «докручивает» число до нового значения (как в банковских
/// приложениях) вместо резкого прыжка. Замена Text для сумм, мл, калорий.
class AnimatedNumber extends StatelessWidget {
  const AnimatedNumber({
    super.key,
    required this.value,
    this.style,
    this.decimals = 0,
    this.prefix = '',
    this.suffix = '',
    this.duration = const Duration(milliseconds: 650),
    this.curve = Curves.easeOutCubic,
    this.textAlign,
    this.formatter,
  });

  final num value;
  final TextStyle? style;
  final int decimals;
  final String prefix;
  final String suffix;
  final Duration duration;
  final Curve curve;
  final TextAlign? textAlign;

  /// Полный контроль над форматом (например, разделители тысяч через intl).
  /// Если задан — prefix/suffix/decimals игнорируются.
  final String Function(double value)? formatter;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: value.toDouble()),
      duration: duration,
      curve: curve,
      builder: (context, v, _) => Text(
        formatter != null
            ? formatter!(v)
            : '$prefix${v.toStringAsFixed(decimals)}$suffix',
        style: style,
        textAlign: textAlign,
      ),
    );
  }
}
