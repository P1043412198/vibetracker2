import 'package:flutter/material.dart';

import 'heat_color.dart';

/// Compact animated vertical bar chart for inline stats (last 7 days, one
/// bar per item, etc.). Bars grow from the bottom; an optional
/// [referenceValue] recolours bars that reached the plan in [vizGood].
class MiniBarChart extends StatelessWidget {
  const MiniBarChart({
    super.key,
    required this.values,
    this.labels,
    this.height = 48,
    this.color,
    this.maxValue,
    this.highlightIndex,
    this.referenceValue,
    this.spacing = 4,
  });

  final List<double> values;

  /// Optional captions under the bars (same length as [values]).
  final List<String>? labels;
  final double height;
  final Color? color;

  /// Scale ceiling. Defaults to the max of [values] (and [referenceValue]).
  final double? maxValue;

  /// Index rendered at full opacity while the rest are dimmed.
  final int? highlightIndex;

  /// Bars with value >= this are painted [vizGood].
  final double? referenceValue;
  final double spacing;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final c = color ?? scheme.primary;
    var maxV = maxValue ??
        values.fold<double>(0, (a, b) => a > b ? a : b);
    if (referenceValue != null && referenceValue! > maxV) {
      maxV = referenceValue!;
    }
    if (maxV <= 0) maxV = 1;

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 700),
      curve: Curves.easeOutCubic,
      builder: (context, t, _) => Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (var i = 0; i < values.length; i++) ...[
            if (i > 0) SizedBox(width: spacing),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: height,
                    child: Stack(
                      children: [
                        // Track
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            decoration: BoxDecoration(
                              color: scheme.surfaceContainerHighest
                                  .withValues(alpha: 0.6),
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: FractionallySizedBox(
                            heightFactor: ((values[i] / maxV) * t)
                                .clamp(0.0, 1.0),
                            child: Container(
                              decoration: BoxDecoration(
                                color: _barColor(i, c),
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (labels != null && i < labels!.length)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(
                        labels![i],
                        maxLines: 1,
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: highlightIndex == i
                              ? FontWeight.w800
                              : FontWeight.w500,
                          color: highlightIndex == i
                              ? scheme.onSurface
                              : scheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _barColor(int i, Color base) {
    var c = base;
    if (referenceValue != null && values[i] >= referenceValue!) {
      c = vizGood;
    }
    if (highlightIndex != null && highlightIndex != i) {
      return c.withValues(alpha: 0.45);
    }
    return c;
  }
}
