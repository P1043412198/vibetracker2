import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../services/storage.dart';
import '../../state/settings_state.dart';

/// Онбординг при первом запуске: приветствие, цель воды, валюта.
/// После завершения ставит флаг `onboardingDone` и больше не показывается.
class OnboardingPage extends ConsumerStatefulWidget {
  const OnboardingPage({super.key});

  @override
  ConsumerState<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends ConsumerState<OnboardingPage> {
  final _controller = PageController();
  int _page = 0;
  int _waterGoal = 2000;
  String _currency = 'BYN';

  static const _currencies = ['BYN', 'USD', 'EUR', 'RUB', 'PLN', 'KZT'];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _finish({required bool save}) async {
    if (save) {
      await ref.read(waterGoalProvider.notifier).set(_waterGoal);
      ref.read(defaultCurrencyProvider.notifier).state = _currency;
      await AppStorage.writeString('defaultCurrency', _currency);
    }
    await AppStorage.writeString('onboardingDone', 'true');
    if (mounted) context.go('/');
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isLast = _page == 2;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => _finish(save: false),
                child: const Text('Пропустить'),
              ),
            ),
            Expanded(
              child: PageView(
                controller: _controller,
                onPageChanged: (i) => setState(() => _page = i),
                children: [
                  _OnboardingSlide(
                    emoji: '\u{1F331}',
                    title: 'Добро пожаловать в VibeSight',
                    subtitle:
                        'Финансы, привычки, тренировки, вода, сон и свои метрики — всё в одном месте, с кольцами, графиками и настраиваемым дашбордом. Пара вопросов — и можно начинать.',
                  ),
                  _OnboardingSlide(
                    emoji: '\u{1F4A7}',
                    title: 'Сколько воды в день?',
                    subtitle:
                        'Обычная рекомендация — около 30 мл на кг веса. Цель всегда можно изменить в настройках.',
                    child: Column(
                      children: [
                        Text(
                          '$_waterGoal мл',
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(
                                  fontWeight: FontWeight.w800,
                                  color: const Color(0xFF06B6D4)),
                        ),
                        Slider(
                          value: _waterGoal.toDouble(),
                          min: 1000,
                          max: 4000,
                          divisions: 12,
                          onChanged: (v) =>
                              setState(() => _waterGoal = v.round()),
                        ),
                      ],
                    ),
                  ),
                  _OnboardingSlide(
                    emoji: '\u{1F4B0}',
                    title: 'Основная валюта',
                    subtitle:
                        'В ней будут показываться баланс, бюджет и аналитика. Курсы НБРБ подтягиваются автоматически.',
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      alignment: WrapAlignment.center,
                      children: [
                        for (final c in _currencies)
                          ChoiceChip(
                            label: Text(c),
                            selected: _currency == c,
                            onSelected: (_) =>
                                setState(() => _currency = c),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Row(
                children: [
                  Row(
                    children: [
                      for (var i = 0; i < 3; i++)
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          margin: const EdgeInsets.only(right: 6),
                          width: i == _page ? 22 : 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: i == _page
                                ? scheme.primary
                                : scheme.outlineVariant,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                    ],
                  ),
                  const Spacer(),
                  FilledButton(
                    onPressed: () {
                      if (isLast) {
                        _finish(save: true);
                      } else {
                        _controller.nextPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeOutCubic,
                        );
                      }
                    },
                    child: Text(isLast ? 'Начать \u{1F680}' : 'Далее'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnboardingSlide extends StatelessWidget {
  const _OnboardingSlide({
    required this.emoji,
    required this.title,
    required this.subtitle,
    this.child,
  });

  final String emoji;
  final String title;
  final String subtitle;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 64)),
          const SizedBox(height: 20),
          Text(
            title,
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(color: scheme.outline),
          ),
          if (child != null) ...[
            const SizedBox(height: 24),
            child!,
          ],
        ],
      ),
    );
  }
}
