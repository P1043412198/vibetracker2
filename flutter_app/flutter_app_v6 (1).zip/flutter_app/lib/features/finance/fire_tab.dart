import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../services/finance_calc.dart';
import '../../services/net_worth.dart';
import '../../state/currency_state.dart';
import '../../state/providers.dart';
import '../../state/settings_state.dart';
import '../../widgets/viz/viz.dart';

/// Вкладка «Свобода» — путь к финансовой независимости (FIRE) на
/// реальных данных: число свободы (25× годовых расходов, правило 4%),
/// норма сбережений, покрытие расходов пассивным доходом и интерактив
/// «когда я свободен».
class FireTab extends ConsumerStatefulWidget {
  const FireTab({super.key});
  @override
  ConsumerState<FireTab> createState() => _FireTabState();
}

class _FireTabState extends ConsumerState<FireTab> {
  double? _rateOverride; // норма сбережений в слайдере, 0..0.8

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final accounts = ref.watch(accountsProvider);
    final transactions = ref.watch(transactionsProvider);
    final loans = ref.watch(loansProvider);
    final loanPayments = ref.watch(loanPaymentsProvider);
    final rates = ref.watch(currencyRatesProvider);
    final baseCurrency = ref.watch(defaultCurrencyProvider);

    num convert(num a, String from, String to) =>
        convertCurrency(amount: a, from: from, to: to, rates: rates);

    // Капитал = текущий net worth.
    final history = computeNetWorthHistory(
      accounts: accounts,
      transactions: transactions,
      loans: loans,
      loanPayments: loanPayments,
      baseCurrency: baseCurrency,
      convert: convert,
      months: 12,
    );
    final capital =
        history.isEmpty ? 0.0 : history.last.netWorth.toDouble();

    // Средние доход/расход за последние 6 полных месяцев.
    final now = DateTime.now();
    final monthRates = <double>[]; // норма сбережений по месяцам
    final monthLabels = <String>[];
    num incomeSum = 0;
    num expenseSum = 0;
    var monthsWithData = 0;
    for (var i = 6; i >= 1; i--) {
      final month = DateTime(now.year, now.month - i, 1);
      final f = computeMonthFacts(
        month: month,
        transactions: transactions,
        accounts: accounts,
        baseCurrency: baseCurrency,
        convert: convert,
      );
      monthLabels.add('${month.month.toString().padLeft(2, '0')}');
      if (f.income > 0 || f.expense > 0) {
        monthsWithData++;
        incomeSum += f.income;
        expenseSum += f.expense;
        monthRates.add(f.income > 0
            ? ((f.income - f.expense) / f.income).clamp(-1.0, 1.0).toDouble()
            : 0.0);
      } else {
        monthRates.add(0);
      }
    }
    // Если истории нет — берём текущий месяц.
    if (monthsWithData == 0) {
      final f = computeMonthFacts(
        month: now,
        transactions: transactions,
        accounts: accounts,
        baseCurrency: baseCurrency,
        convert: convert,
      );
      incomeSum = f.income;
      expenseSum = f.expense;
      monthsWithData = 1;
    }
    final avgIncome = incomeSum / monthsWithData;
    final avgExpense = expenseSum / monthsWithData;

    final annualExpenses = avgExpense * 12;
    final freedomNumber = annualExpenses * 25; // правило 4%
    final progress = freedomNumber > 0
        ? (capital / freedomNumber).clamp(0.0, 1.0)
        : 0.0;
    final actualRate = avgIncome > 0
        ? ((avgIncome - avgExpense) / avgIncome).clamp(0.0, 0.8).toDouble()
        : 0.2;
    final rate = _rateOverride ?? actualRate;

    // Пассивный доход по правилу 4%.
    final passiveMonthly = capital > 0 ? capital * 0.04 / 12 : 0.0;
    final coverage = avgExpense > 0
        ? (passiveMonthly / avgExpense).clamp(0.0, 1.0)
        : 0.0;

    // Симуляция: через сколько лет капитал достигнет числа свободы
    // при выбранной норме сбережений и 5% реальной доходности.
    int? yearsToFi;
    if (freedomNumber > 0 && avgIncome > 0) {
      final monthlySave = avgIncome * rate;
      const monthlyReturn = 0.05 / 12;
      var cap = capital;
      var months = 0;
      while (cap < freedomNumber && months < 12 * 60) {
        cap = cap * (1 + monthlyReturn) + monthlySave;
        months++;
      }
      if (cap >= freedomNumber) yearsToFi = (months / 12).ceil();
    }

    String fmt(num v) => v.abs() >= 1000000
        ? '${(v / 1000000).toStringAsFixed(2)}М'
        : v.abs() >= 10000
            ? '${(v / 1000).toStringAsFixed(1)}к'
            : v.toStringAsFixed(0);

    const green = Color(0xFF22C55E);
    const amber = Color(0xFFF59E0B);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // --- Герой-карточка: прогресс к свободе ---
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text('Путь к финансовой независимости',
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 16),
                AnimatedProgressRing(
                  progress: progress.toDouble(),
                  color: progress >= 1.0 ? green : amber,
                  size: 150,
                  strokeWidth: 12,
                  center: AnimatedNumber(
                    value: progress * 100,
                    decimals: 1,
                    suffix: '%',
                    style: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(fontWeight: FontWeight.w800),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Column(
                      children: [
                        Text('Капитал',
                            style: Theme.of(context)
                                .textTheme
                                .labelSmall
                                ?.copyWith(color: scheme.outline)),
                        Text('${fmt(capital)} $baseCurrency',
                            style: Theme.of(context)
                                .textTheme
                                .titleSmall
                                ?.copyWith(fontWeight: FontWeight.w700)),
                      ],
                    ),
                    Column(
                      children: [
                        Text('Число свободы',
                            style: Theme.of(context)
                                .textTheme
                                .labelSmall
                                ?.copyWith(color: scheme.outline)),
                        Text('${fmt(freedomNumber)} $baseCurrency',
                            style: Theme.of(context)
                                .textTheme
                                .titleSmall
                                ?.copyWith(fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'Число свободы = 25 годовых расходов (правило 4%): капитал такого размера покрывает твои траты бессрочно.',
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: scheme.outline),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        // --- Пассивный доход ---
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Пассивный доход уже сейчас',
                    style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: coverage.toDouble(),
                    minHeight: 10,
                    color: green,
                    backgroundColor: scheme.surfaceContainerHighest,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  avgExpense > 0
                      ? 'Капитал покрывает ${(coverage * 100).toStringAsFixed(0)}% месячных расходов: ~${fmt(passiveMonthly)} $baseCurrency/мес при снятии 4% в год',
                      : 'Добавь расходы, чтобы увидеть покрытие пассивным доходом',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        // --- Норма сбережений ---
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text('Норма сбережений',
                          style: Theme.of(context).textTheme.titleSmall),
                    ),
                    AnimatedNumber(
                      value: actualRate * 100,
                      suffix: '%',
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(
                              fontWeight: FontWeight.w800, color: green),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'Среднее за $monthsWithData мес: доход ${fmt(avgIncome)}, расходы ${fmt(avgExpense)} $baseCurrency',
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: scheme.outline),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 64,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      for (var i = 0; i < monthRates.length; i++) ...[
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                height: (48 *
                                        monthRates[i].clamp(0.0, 1.0))
                                    .clamp(2.0, 48.0),
                                decoration: BoxDecoration(
                                  color: monthRates[i] > 0
                                      ? green
                                      : scheme.outlineVariant,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(monthLabels[i],
                                  style: Theme.of(context)
                                      .textTheme
                                      .labelSmall
                                      ?.copyWith(color: scheme.outline)),
                            ],
                          ),
                        ),
                        if (i != monthRates.length - 1)
                          const SizedBox(width: 6),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        // --- Интерактив «когда свобода» ---
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Когда я буду свободен?',
                    style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 4),
                Text(
                  'Подвигай норму сбережений и посмотри, как меняется срок (доходность 5% годовых сверх инфляции).',
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: scheme.outline),
                ),
                Slider(
                  value: (rate * 100).clamp(5.0, 80.0),
                  min: 5,
                  max: 80,
                  divisions: 75,
                  label: '${(rate * 100).toStringAsFixed(0)}%',
                  onChanged: (v) =>
                      setState(() => _rateOverride = v / 100),
                ),
                Center(
                  child: Text(
                    avgIncome <= 0
                        ? 'Добавь доходы — и я посчитаю срок до свободы'
                        : yearsToFi == null
                            ? 'При такой норме сбережений цель дальше 60 лет — попробуй больше'
                            : yearsToFi == 0
                                ? '\u{1F389} Ты уже финансово свободен!'
                                : 'Откладывая ${(rate * 100).toStringAsFixed(0)}% дохода — свобода через ~$yearsToFi лет (${now.year + (yearsToFi ?? 0)} год)',
                    style: Theme.of(context)
                        .textTheme
                        .titleSmall
                        ?.copyWith(fontWeight: FontWeight.w700),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (avgIncome <= 0 || avgExpense <= 0)
          Card(
            color: scheme.surfaceContainerHighest,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Чем больше доходов и расходов ты вносишь во вкладке «Транзакции», тем точнее расчёт твоего пути к свободе.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ),
      ],
    );
  }
}
