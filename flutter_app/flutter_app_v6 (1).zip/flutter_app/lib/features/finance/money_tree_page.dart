import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../services/storage.dart';
import '../../state/settings_state.dart';
import '../../widgets/viz/viz.dart';

/// Копилка-«денежное дерево»: дерево растёт по мере пополнения.
/// Состояние хранится в Hive (`moneyTreeState`), не зависит от счетов.
class MoneyTreePage extends ConsumerStatefulWidget {
  const MoneyTreePage({super.key});
  @override
  ConsumerState<MoneyTreePage> createState() => _MoneyTreePageState();
}

class _MoneyTreePageState extends ConsumerState<MoneyTreePage> {
  static const _key = 'moneyTreeState';

  double _goal = 1000;
  List<Map<String, dynamic>> _entries = [];

  @override
  void initState() {
    super.initState();
    final raw = AppStorage.readString(_key);
    if (raw != null && raw.isNotEmpty) {
      try {
        final m = json.decode(raw);
        if (m is Map) {
          _goal = ((m['goal'] as num?) ?? 1000).toDouble();
          final list = m['entries'];
          if (list is List) {
            _entries = [
              for (final e in list)
                if (e is Map)
                  {'date': e['date'], 'amount': e['amount']},
            ];
          }
        }
      } catch (_) {}
    }
  }

  double get _total =>
      _entries.fold<double>(0, (s, e) => s + ((e['amount'] as num?) ?? 0));

  Future<void> _persist() => AppStorage.writeString(
      _key, json.encode({'goal': _goal, 'entries': _entries}));

  ({String emoji, String label}) _stage(double p) {
    if (_total <= 0) {
      return (emoji: '\u{1F330}', label: 'Посади дерево — сделай первый взнос');
    }
    if (p < 0.15) return (emoji: '\u{1F331}', label: 'Росток проклюнулся!');
    if (p < 0.35) return (emoji: '\u{1F33F}', label: 'Дерево набирает силу');
    if (p < 0.60) return (emoji: '\u{1FAB4}', label: 'Уже настоящее деревце');
    if (p < 0.85) return (emoji: '\u{1F333}', label: 'Крона разрастается');
    if (p < 1.0) return (emoji: '\u{1F333}', label: 'Почти у цели — скоро плоды!');
    return (emoji: '\u{1F333}\u{1F34E}', label: 'Дерево плодоносит — цель достигнута!');
  }

  Future<double?> _promptAmount(String title) async {
    final ctrl = TextEditingController();
    return showDialog<double>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Сумма',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
          FilledButton(
            onPressed: () {
              final v = double.tryParse(ctrl.text.replaceAll(',', '.'));
              Navigator.pop(ctx, v);
            },
            child: const Text('ОК'),
          ),
        ],
      ),
    );
  }

  Future<void> _deposit() async {
    final v = await _promptAmount('Пополнить копилку');
    if (v == null || v <= 0) return;
    final wasBelow = _total < _goal;
    setState(() {
      _entries.add({
        'date': DateTime.now().toIso8601String(),
        'amount': v,
      });
    });
    HapticFeedback.lightImpact();
    await _persist();
    if (wasBelow && _total >= _goal && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content:
                Text('\u{1F389} Цель достигнута! Дерево плодоносит — поставь новую цель!')),
      );
    }
  }

  Future<void> _withdraw() async {
    final v = await _promptAmount('Снять из копилки');
    if (v == null || v <= 0) return;
    final amount = v > _total ? _total : v;
    if (amount <= 0) return;
    setState(() {
      _entries.add({
        'date': DateTime.now().toIso8601String(),
        'amount': -amount,
      });
    });
    await _persist();
  }

  Future<void> _editGoal() async {
    final v = await _promptAmount('Новая цель копилки');
    if (v == null || v <= 0) return;
    setState(() => _goal = v);
    await _persist();
  }

  /// Оценка «цель через ~N дней» по среднему темпу пополнений.
  String? _forecast() {
    if (_total >= _goal || _entries.isEmpty) return null;
    final dates = <DateTime>[];
    for (final e in _entries) {
      final d = DateTime.tryParse((e['date'] ?? '') as String);
      if (d != null) dates.add(d);
    }
    if (dates.isEmpty) return null;
    dates.sort();
    final days = DateTime.now().difference(dates.first).inDays + 1;
    final perDay = _total / days;
    if (perDay <= 0) return null;
    final left = ((_goal - _total) / perDay).ceil();
    return 'Таким темпом цель через ~$left дн.';
  }

  String _fmtDate(String iso) {
    final d = DateTime.tryParse(iso);
    if (d == null) return '';
    final dd = d.day.toString().padLeft(2, '0');
    final mm = d.month.toString().padLeft(2, '0');
    return '$dd.$mm.${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    final currency = ref.watch(defaultCurrencyProvider);
    final scheme = Theme.of(context).colorScheme;
    final p = _goal > 0 ? (_total / _goal).clamp(0.0, 1.0) : 0.0;
    final stage = _stage(p);
    final forecast = _forecast();
    const green = Color(0xFF22C55E);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Денежное дерево'),
        actions: [
          IconButton(
            tooltip: 'Изменить цель',
            icon: const Icon(Icons.tune),
            onPressed: _editGoal,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: AnimatedProgressRing(
              progress: p.toDouble(),
              color: green,
              size: 190,
              strokeWidth: 14,
              center: AnimatedSwitcher(
                duration: const Duration(milliseconds: 400),
                transitionBuilder: (child, anim) =>
                    ScaleTransition(scale: anim, child: child),
                child: _AnimatedTree(
                  key: ValueKey(stage.emoji),
                  emoji: stage.emoji,
                  size: 56,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: AnimatedNumber(
              value: _total,
              decimals: 2,
              suffix: ' $currency',
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(fontWeight: FontWeight.w800),
            ),
          ),
          Center(
            child: Text(
              'цель: ${_goal.toStringAsFixed(0)} $currency · ${(p * 100).toStringAsFixed(0)}%',
              style: Theme.of(context)
                  .textTheme
                  .bodySmall
                  ?.copyWith(color: scheme.outline),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Text(stage.label,
                style: Theme.of(context).textTheme.titleSmall),
          ),
          if (forecast != null) ...[
            const SizedBox(height: 4),
            Center(
              child: Text(forecast,
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: scheme.outline)),
            ),
          ],
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _deposit,
                  icon: const Icon(Icons.add),
                  label: const Text('Пополнить'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _withdraw,
                  icon: const Icon(Icons.remove),
                  label: const Text('Снять'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          if (_entries.isNotEmpty) ...[
            Text('История', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            for (final e in _entries.reversed.take(30))
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(
                  ((e['amount'] as num?) ?? 0) >= 0
                      ? Icons.arrow_upward
                      : Icons.arrow_downward,
                  size: 18,
                  color: ((e['amount'] as num?) ?? 0) >= 0
                      ? green
                      : scheme.error,
                ),
                title: Text(
                    '${(((e['amount'] as num?) ?? 0)).toStringAsFixed(2)} $currency'),
                trailing: Text(_fmtDate((e['date'] ?? '') as String),
                    style: Theme.of(context)
                        .textTheme
                        .labelSmall
                        ?.copyWith(color: scheme.outline)),
              ),
          ],
        ],
      ),
    );
  }
}

/// Компактная карточка для дашборда — тап открывает копилку.
class MoneyTreeCard extends StatelessWidget {
  const MoneyTreeCard({super.key});

  @override
  Widget build(BuildContext context) {
    double goal = 1000;
    double total = 0;
    final raw = AppStorage.readString('moneyTreeState');
    if (raw != null && raw.isNotEmpty) {
      try {
        final m = json.decode(raw);
        if (m is Map) {
          goal = ((m['goal'] as num?) ?? 1000).toDouble();
          final list = m['entries'];
          if (list is List) {
            for (final e in list) {
              if (e is Map) total += ((e['amount'] as num?) ?? 0).toDouble();
            }
          }
        }
      } catch (_) {}
    }
    final p = goal > 0 ? (total / goal).clamp(0.0, 1.0) : 0.0;
    final String emoji = total <= 0
        ? '\u{1F330}'
        : p < 0.15
            ? '\u{1F331}'
            : p < 0.35
                ? '\u{1F33F}'
                : p < 0.6
                    ? '\u{1FAB4}'
                        : p < 1.0
                            ? '\u{1F333}'
                            : '\u{1F333}\u{1F34E}';
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => GoRouter.of(context).go('/money-tree'),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              _AnimatedTree(emoji: emoji, size: 32),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Денежное дерево',
                        style: Theme.of(context).textTheme.titleSmall),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: p.toDouble(),
                        minHeight: 8,
                        color: const Color(0xFF22C55E),
                        backgroundColor:
                            scheme.surfaceContainerHighest,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Text('${(p * 100).toStringAsFixed(0)}%',
                  style: Theme.of(context)
                      .textTheme
                      .titleSmall
                      ?.copyWith(fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Живое дерево: лёгкое покачивание и «дыхание» в бесконечном цикле.
class _AnimatedTree extends StatefulWidget {
  const _AnimatedTree({super.key, required this.emoji, this.size = 56});

  final String emoji;
  final double size;

  @override
  State<_AnimatedTree> createState() => _AnimatedTreeState();
}

class _AnimatedTreeState extends State<_AnimatedTree>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2200),
  )..repeat(reverse: true);

  late final Animation<double> _t =
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _t,
      builder: (context, child) {
        final v = _t.value; // 0..1
        return Transform.rotate(
          angle: (v - 0.5) * 0.12, // покачивание ±3.5°
          child: Transform.scale(
            scale: 0.97 + v * 0.06, // «дыхание»
            child: child,
          ),
        );
      },
      child: Text(widget.emoji, style: TextStyle(fontSize: widget.size)),
    );
  }
}
