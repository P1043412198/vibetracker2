import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../models/enums.dart';
import '../../services/finance_calc.dart';
import '../../state/currency_state.dart';
import '../../state/providers.dart';
import '../../state/settings_state.dart';
import '../../widgets/viz/viz.dart';

/// Живое правило 50/30/20 + «финансовая подушка» на реальных данных.
///
/// В отличие от статичных советов в разделе финграмотности, эта
/// карточка считает доли «обязательное / желаемое / накопления»
/// по транзакциям текущего месяца, а подушку — из баланса счетов
/// и среднего расхода за последние месяцы.
class FinlitLiveCard extends ConsumerWidget {
  const FinlitLiveCard({super.key});

  static const _needsKeywords = [
    'продукт', 'еда', 'коммунал', 'жкх', 'квартплат', 'аренд',
    'жиль', 'транспорт', 'проезд', 'бензин', 'топлив', 'авто',
    'связ', 'интернет', 'телефон', 'здоров', 'аптек', 'лекарств',
    'медиц', 'кредит', 'рассрочк', 'налог', 'страхов', 'дет',
    'образован', 'школ', 'бытовая хим', 'гигиен',
  ];

  static bool _isNeed(String category) {
    final c = category.toLowerCase();
    return _needsKeywords.any(c.contains);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final transactions = ref.watch(transactionsProvider);
    final accounts = ref.watch(accountsProvider);
    final baseCurrency = ref.watch(defaultCurrencyProvider);
    final rates = ref.watch(currencyRatesProvider);

    num convert(num amount, String from, String to) =>
        convertCurrency(amount: amount, from: from, to: to, rates: rates);

    final now = DateTime.now();
    final facts = computeMonthFacts(
      month: now,
      transactions: transactions,
      accounts: accounts,
      baseCurrency: baseCurrency,
      convert: convert,
    );

    num needs = 0;
    num wants = 0;
    facts.expenseByCategory.forEach((category, sum) {
      if (_isNeed(category)) {
        needs += sum;
      } else {
        wants += sum;
      }
    });
    final income = facts.income;
    final savings =
        (income - facts.expense) > 0 ? income - facts.expense : 0;

    // Средний месячный расход — по последним 3 завершённым месяцам
    // (если истории нет — по текущему месяцу).
    num pastExpense = 0;
    var pastMonths = 0;
    for (var i = 1; i <= 3; i++) {
      final m = DateTime(now.year, now.month - i, 1);
      final f = computeMonthFacts(
        month: m,
        transactions: transactions,
        accounts: accounts,
        baseCurrency: baseCurrency,
        convert: convert,
      );
      if (f.expense > 0) {
        pastExpense += f.expense;
        pastMonths++;
      }
    }
    final avgMonthlyExpense = pastMonths > 0
        ? pastExpense / pastMonths
        : (facts.expense > 0 ? facts.expense : 0);

    final totalBalance = accounts.fold<num>(
      0,
      (sum, a) =>
          sum +
          convert(
            accountBalance(
              account: a,
              transactions: transactions,
              accounts: accounts,
              convert: convert,
            ),
            a.currency,
            baseCurrency,
          ),
    );
    final cushionMonths = avgMonthlyExpense > 0
        ? (totalBalance / avgMonthlyExpense).clamp(0, 99).toDouble()
        : 0.0;

    final fmt = NumberFormat.currency(
        locale: 'ru_RU', symbol: baseCurrency, decimalDigits: 0);

    Widget ring({
      required String title,
      required num value,
      required double targetShare,
      required Color color,
    }) {
      final share = income > 0 ? (value / income).toDouble() : 0.0;
      final over = income > 0 && share > targetShare + 0.005;
      final c = over ? scheme.error : color;
      return Expanded(
        child: Column(
          children: [
            AnimatedProgressRing(
              progress: targetShare == 0
                  ? 0
                  : (share / targetShare).clamp(0.0, 1.0),
              color: c,
              size: 86,
              center: '${(share * 100).round()}%',
            ),
            const SizedBox(height: 6),
            Text(title,
                style: Theme.of(context).textTheme.labelMedium,
                textAlign: TextAlign.center),
            Text(
              '${fmt.format(value)} \u00B7 цель ${(targetShare * 100).round()}%',
              style: Theme.of(context)
                  .textTheme
                  .labelSmall
                  ?.copyWith(color: over ? scheme.error : scheme.outline),
              textAlign: TextAlign.center,
            ),
            if (over)
              Text('перебор',
                  style: Theme.of(context)
                      .textTheme
                      .labelSmall
                      ?.copyWith(
                          color: scheme.error,
                          fontWeight: FontWeight.w700)),
          ],
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.school_outlined, size: 18, color: scheme.primary),
                const SizedBox(width: 8),
                Text('50/30/20 в этом месяце',
                    style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 12),
            if (income <= 0)
              Text(
                'Добавь доходы за месяц — и я покажу, как твои траты '
                'ложатся в правило 50/30/20.',
                style: TextStyle(color: scheme.outline),
              )
            else
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ring(
                      title: 'Обязательное',
                      value: needs,
                      targetShare: 0.5,
                      color: const Color(0xFF3B82F6)),
                  ring(
                      title: 'Желаемое',
                      value: wants,
                      targetShare: 0.3,
                      color: const Color(0xFFF59E0B)),
                  ring(
                      title: 'Накопления',
                      value: savings,
                      targetShare: 0.2,
                      color: const Color(0xFF22C55E)),
                ],
              ),
            const Divider(height: 24),
            Row(
              children: [
                Icon(Icons.shield_outlined, size: 18, color: scheme.primary),
                const SizedBox(width: 8),
                Text('Финансовая подушка',
                    style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 8),
            if (avgMonthlyExpense <= 0)
              Text(
                'Нужна история расходов, чтобы посчитать, на сколько '
                'месяцев жизни хватит накоплений.',
                style: TextStyle(color: scheme.outline),
              )
            else ...[
              Text(
                'Накоплений хватит на '
                '${cushionMonths.toStringAsFixed(1)} мес. жизни '
                '(средний расход ${fmt.format(avgMonthlyExpense)}/мес).',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 8),
              ValueSliderBar(
                value: cushionMonths.clamp(0.0, 6.0),
                max: 6,
                height: 12,
                color: cushionMonths >= 6
                    ? const Color(0xFF22C55E)
                    : cushionMonths >= 3
                        ? const Color(0xFFF59E0B)
                        : scheme.error,
                valueLabel:
                    '${cushionMonths.toStringAsFixed(1)} / 6 мес',
              ),
              const SizedBox(height: 4),
              Text(
                cushionMonths >= 6
                    ? 'Цель достигнута: подушка на 6+ месяцев. Отличная защита!'
                    : 'Цель — 6 месяцев расходов. Осталось накопить '
                        '${fmt.format((avgMonthlyExpense * 6 - totalBalance).clamp(0, double.maxFinite))}.',
                style: Theme.of(context)
                    .textTheme
                    .labelSmall
                    ?.copyWith(color: scheme.outline),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
