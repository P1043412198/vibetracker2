import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:uuid/uuid.dart';

import '../../services/storage.dart';
import '../../widgets/viz/viz.dart';

/// Конструктор метрик «отслеживай всё»: любая своя метрика
/// (число / шкала 1–10 / да-нет) с целью, периодом и выбором виджета
/// отображения (кольцо / бар / мини-график).

const _uuid = Uuid();

String _dateStr(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

const kMetricColors = <int>[
  0xFF3B82F6,
  0xFF8B5CF6,
  0xFF22C55E,
  0xFFF59E0B,
  0xFF06B6D4,
  0xFFEF4444,
];

class CustomMetric {
  const CustomMetric({
    required this.id,
    required this.name,
    required this.unit,
    required this.type, // 'number' | 'scale' | 'yesno'
    required this.goal,
    required this.period, // 'day' | 'week'
    required this.color,
    required this.viz, // 'ring' | 'bar' | 'spark'
  });

  final String id;
  final String name;
  final String unit;
  final String type;
  final double goal;
  final String period;
  final int color;
  final String viz;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'unit': unit,
        'type': type,
        'goal': goal,
        'period': period,
        'color': color,
        'viz': viz,
      };

  factory CustomMetric.fromJson(Map<String, dynamic> json) => CustomMetric(
        id: (json['id'] ?? '') as String,
        name: (json['name'] ?? '') as String,
        unit: (json['unit'] ?? '') as String,
        type: (json['type'] ?? 'number') as String,
        goal: ((json['goal'] as num?) ?? 1).toDouble(),
        period: (json['period'] ?? 'day') as String,
        color: ((json['color'] as num?) ?? kMetricColors.first).toInt(),
        viz: (json['viz'] ?? 'ring') as String,
      );
}

class MetricLog {
  const MetricLog({
    required this.id,
    required this.metricId,
    required this.date, // YYYY-MM-DD
    required this.value,
  });

  final String id;
  final String metricId;
  final String date;
  final num value;

  Map<String, dynamic> toJson() =>
      {'id': id, 'metricId': metricId, 'date': date, 'value': value};

  factory MetricLog.fromJson(Map<String, dynamic> json) => MetricLog(
        id: (json['id'] ?? '') as String,
        metricId: (json['metricId'] ?? '') as String,
        date: (json['date'] ?? '') as String,
        value: (json['value'] as num?) ?? 0,
      );
}

class CustomMetricsController extends StateNotifier<List<CustomMetric>> {
  CustomMetricsController() : super(const []) {
    state = [
      for (final m in AppStorage.readList('customMetrics'))
        CustomMetric.fromJson(m),
    ];
  }

  Future<void> _persist() => AppStorage.writeList(
      'customMetrics', [for (final m in state) m.toJson()]);

  void upsert(CustomMetric m) {
    final i = state.indexWhere((e) => e.id == m.id);
    state = i < 0
        ? [...state, m]
        : [for (final e in state) e.id == m.id ? m : e];
    _persist();
  }

  void remove(String id) {
    state = [for (final e in state) if (e.id != id) e];
    _persist();
  }
}

final customMetricsProvider =
    StateNotifierProvider<CustomMetricsController, List<CustomMetric>>(
        (ref) => CustomMetricsController());

class MetricLogsController extends StateNotifier<List<MetricLog>> {
  MetricLogsController() : super(const []) {
    state = [
      for (final m in AppStorage.readList('customMetricLogs'))
        MetricLog.fromJson(m),
    ];
  }

  Future<void> _persist() => AppStorage.writeList(
      'customMetricLogs', [for (final m in state) m.toJson()]);

  void add(String metricId, num value, {String? date}) {
    state = [
      ...state,
      MetricLog(
        id: _uuid.v4(),
        metricId: metricId,
        date: date ?? _dateStr(DateTime.now()),
        value: value,
      ),
    ];
    _persist();
  }

  /// Для «да-нет»: переключить отметку за сегодня.
  void toggleToday(String metricId) {
    final today = _dateStr(DateTime.now());
    final existing = state
        .where((l) => l.metricId == metricId && l.date == today)
        .toList();
    if (existing.isEmpty) {
      add(metricId, 1);
    } else {
      final ids = existing.map((e) => e.id).toSet();
      state = [for (final l in state) if (!ids.contains(l.id)) l];
      _persist();
    }
  }

  void removeForMetric(String metricId) {
    state = [for (final l in state) if (l.metricId != metricId) l];
    _persist();
  }
}

final metricLogsProvider =
    StateNotifierProvider<MetricLogsController, List<MetricLog>>(
        (ref) => MetricLogsController());

// ---------------------------------------------------------------------------
// Хелперы расчёта
// ---------------------------------------------------------------------------

num metricValueForPeriod(CustomMetric m, List<MetricLog> logs) {
  final now = DateTime.now();
  if (m.period == 'week') {
    final weekStart = now.subtract(Duration(days: now.weekday - 1));
    final days = <String>{
      for (var i = 0; i < 7; i++)
        _dateStr(DateTime(weekStart.year, weekStart.month, weekStart.day + i)),
    };
    return logs
        .where((l) => l.metricId == m.id && days.contains(l.date))
        .fold<num>(0, (s, l) => s + l.value);
  }
  final today = _dateStr(now);
  return logs
      .where((l) => l.metricId == m.id && l.date == today)
      .fold<num>(0, (s, l) => s + l.value);
}

List<num> metricLast7Days(CustomMetric m, List<MetricLog> logs) {
  final now = DateTime.now();
  final out = <num>[];
  for (var i = 6; i >= 0; i--) {
    final d = _dateStr(DateTime(now.year, now.month, now.day - i));
    out.add(logs
        .where((l) => l.metricId == m.id && l.date == d)
        .fold<num>(0, (s, l) => s + l.value));
  }
  return out;
}

// ---------------------------------------------------------------------------
// Страница
// ---------------------------------------------------------------------------

class MetricsPage extends ConsumerWidget {
  const MetricsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final metrics = ref.watch(customMetricsProvider);
    final logs = ref.watch(metricLogsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Мои метрики')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showMetricForm(context, ref),
        icon: const Icon(Icons.add),
        label: const Text('Метрика'),
      ),
      body: metrics.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('\u{1F4D0}', style: TextStyle(fontSize: 48)),
                    const SizedBox(height: 12),
                    Text('Отслеживай что угодно',
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    Text(
                      'Страницы книг, часы без телефона, чашки кофе, настроение — создай метрику с целью и выбери, каким виджетом её показывать.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              children: [
                for (final m in metrics)
                  _MetricCard(metric: m, logs: logs),
              ],
            ),
    );
  }
}

class _MetricCard extends ConsumerWidget {
  const _MetricCard({required this.metric, required this.logs});

  final CustomMetric metric;
  final List<MetricLog> logs;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final color = Color(metric.color);
    final value = metricValueForPeriod(metric, logs);
    final p = metric.goal > 0
        ? (value / metric.goal).clamp(0.0, 1.0).toDouble()
        : 0.0;
    final week = metricLast7Days(metric, logs);
    final weekMax = week.fold<num>(0, (m, v) => v > m ? v : m);

    Widget vizWidget;
    switch (metric.viz) {
      case 'bar':
        vizWidget = SizedBox(
          width: 64,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: p,
              minHeight: 10,
              color: color,
              backgroundColor: scheme.surfaceContainerHighest,
            ),
          ),
        );
        break;
      case 'spark':
        vizWidget = SizedBox(
          width: 64,
          height: 36,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (var i = 0; i < week.length; i++) ...[
                Expanded(
                  child: Container(
                    height: weekMax > 0
                        ? (30 * week[i] / weekMax).clamp(2, 30).toDouble()
                        : 2,
                    decoration: BoxDecoration(
                      color: i == week.length - 1
                          ? color
                          : color.withValues(alpha: 0.4),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                if (i != week.length - 1) const SizedBox(width: 2),
              ],
            ],
          ),
        );
        break;
      default:
        vizWidget = AnimatedProgressRing(
          progress: p,
          color: color,
          size: 56,
          strokeWidth: 6,
          center: Text('${(p * 100).toStringAsFixed(0)}%',
              style: Theme.of(context)
                  .textTheme
                  .labelSmall
                  ?.copyWith(fontWeight: FontWeight.w700)),
        );
    }

    final periodLabel = metric.period == 'week' ? 'за неделю' : 'сегодня';

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onLongPress: () => _showMetricForm(context, ref, metric: metric),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              vizWidget,
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(metric.name,
                        style: Theme.of(context).textTheme.titleSmall),
                    const SizedBox(height: 2),
                    Text(
                      metric.type == 'yesno'
                          ? (value > 0 ? 'Выполнено $periodLabel' : 'Ещё не отмечено $periodLabel')
                          : '${value.toStringAsFixed(value == value.roundToDouble() ? 0 : 1)} / ${metric.goal.toStringAsFixed(metric.goal == metric.goal.roundToDouble() ? 0 : 1)} ${metric.unit} $periodLabel',
                      style: Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.copyWith(color: scheme.outline),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              if (metric.type == 'yesno')
                IconButton.filledTonal(
                  icon: Icon(value > 0 ? Icons.check : Icons.close, size: 20),
                  color: value > 0 ? color : null,
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    ref
                        .read(metricLogsProvider.notifier)
                        .toggleToday(metric.id);
                  },
                )
              else
                IconButton.filledTonal(
                  icon: const Icon(Icons.add, size: 20),
                  onPressed: () => _promptLog(context, ref),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _promptLog(BuildContext context, WidgetRef ref) async {
    if (metric.type == 'scale') {
      var v = 5.0;
      final res = await showDialog<double>(
        context: context,
        builder: (ctx) => StatefulBuilder(
          builder: (ctx, setSt) => AlertDialog(
            title: Text(metric.name),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(v.toStringAsFixed(0),
                    style: Theme.of(ctx).textTheme.headlineMedium),
                Slider(
                  value: v,
                  min: 1,
                  max: 10,
                  divisions: 9,
                  onChanged: (nv) => setSt(() => v = nv),
                ),
              ],
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Отмена')),
              FilledButton(
                  onPressed: () => Navigator.pop(ctx, v),
                  child: const Text('Сохранить')),
            ],
          ),
        ),
      );
      if (res != null) {
        HapticFeedback.lightImpact();
        ref.read(metricLogsProvider.notifier).add(metric.id, res);
      }
      return;
    }
    final ctrl = TextEditingController();
    final res = await showDialog<double>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${metric.name} — добавить'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType:
              const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
            labelText: 'Сколько ${metric.unit.isEmpty ? '' : '(${metric.unit})'}',
            border: const OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Отмена')),
          FilledButton(
            onPressed: () => Navigator.pop(
                ctx, double.tryParse(ctrl.text.replaceAll(',', '.'))),
            child: const Text('Добавить'),
          ),
        ],
      ),
    );
    if (res != null && res > 0) {
      HapticFeedback.lightImpact();
      ref.read(metricLogsProvider.notifier).add(metric.id, res);
    }
  }
}

// ---------------------------------------------------------------------------
// Форма создания/редактирования
// ---------------------------------------------------------------------------

Future<void> _showMetricForm(BuildContext context, WidgetRef ref,
    {CustomMetric? metric}) async {
  final nameCtrl = TextEditingController(text: metric?.name ?? '');
  final unitCtrl = TextEditingController(text: metric?.unit ?? '');
  final goalCtrl = TextEditingController(
      text: metric == null ? '' : metric.goal.toStringAsFixed(0));
  var type = metric?.type ?? 'number';
  var period = metric?.period ?? 'day';
  var viz = metric?.viz ?? 'ring';
  var color = metric?.color ?? kMetricColors.first;

  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSt) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(metric == null ? 'Новая метрика' : 'Изменить метрику',
                  style: Theme.of(ctx).textTheme.titleMedium),
              const SizedBox(height: 12),
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(
                  labelText: 'Название (например, «Страницы книги»)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              Text('Тип', style: Theme.of(ctx).textTheme.labelMedium),
              Wrap(
                spacing: 8,
                children: [
                  ChoiceChip(
                    label: const Text('Число'),
                    selected: type == 'number',
                    onSelected: (_) => setSt(() => type = 'number'),
                  ),
                  ChoiceChip(
                    label: const Text('Шкала 1–10'),
                    selected: type == 'scale',
                    onSelected: (_) => setSt(() => type = 'scale'),
                  ),
                  ChoiceChip(
                    label: const Text('Да/нет'),
                    selected: type == 'yesno',
                    onSelected: (_) => setSt(() => type = 'yesno'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (type == 'number') ...[
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: goalCtrl,
                        keyboardType: const TextInputType.numberWithOptions(
                            decimal: true),
                        decoration: const InputDecoration(
                          labelText: 'Цель',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        controller: unitCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Единица (стр., мл, мин…)',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
              ],
              Text('Период цели', style: Theme.of(ctx).textTheme.labelMedium),
              Wrap(
                spacing: 8,
                children: [
                  ChoiceChip(
                    label: const Text('День'),
                    selected: period == 'day',
                    onSelected: (_) => setSt(() => period = 'day'),
                  ),
                  ChoiceChip(
                    label: const Text('Неделя'),
                    selected: period == 'week',
                    onSelected: (_) => setSt(() => period = 'week'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text('Виджет', style: Theme.of(ctx).textTheme.labelMedium),
              Wrap(
                spacing: 8,
                children: [
                  ChoiceChip(
                    label: const Text('Кольцо'),
                    selected: viz == 'ring',
                    onSelected: (_) => setSt(() => viz = 'ring'),
                  ),
                  ChoiceChip(
                    label: const Text('Бар'),
                    selected: viz == 'bar',
                    onSelected: (_) => setSt(() => viz = 'bar'),
                  ),
                  ChoiceChip(
                    label: const Text('График 7 дней'),
                    selected: viz == 'spark',
                    onSelected: (_) => setSt(() => viz = 'spark'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text('Цвет', style: Theme.of(ctx).textTheme.labelMedium),
              const SizedBox(height: 4),
              Wrap(
                spacing: 8,
                children: [
                  for (final c in kMetricColors)
                    GestureDetector(
                      onTap: () => setSt(() => color = c),
                      child: Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: Color(c),
                          shape: BoxShape.circle,
                          border: color == c
                              ? Border.all(
                                  width: 3,
                                  color: Theme.of(ctx)
                                      .colorScheme
                                      .onSurface)
                              : null,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  if (metric != null)
                    TextButton.icon(
                      onPressed: () {
                        ref
                            .read(customMetricsProvider.notifier)
                            .remove(metric.id);
                        ref
                            .read(metricLogsProvider.notifier)
                            .removeForMetric(metric.id);
                        Navigator.pop(ctx);
                      },
                      icon: const Icon(Icons.delete_outline),
                      label: const Text('Удалить'),
                    ),
                  const Spacer(),
                  FilledButton(
                    onPressed: () {
                      final name = nameCtrl.text.trim();
                      if (name.isEmpty) return;
                      final goal = type == 'yesno'
                          ? 1.0
                          : type == 'scale'
                              ? 10.0
                              : (double.tryParse(goalCtrl.text
                                      .replaceAll(',', '.')) ??
                                  1.0);
                      ref.read(customMetricsProvider.notifier).upsert(
                            CustomMetric(
                              id: metric?.id ?? _uuid.v4(),
                              name: name,
                              unit: unitCtrl.text.trim(),
                              type: type,
                              goal: goal <= 0 ? 1.0 : goal,
                              period: period,
                              color: color,
                              viz: viz,
                            ),
                          );
                      Navigator.pop(ctx);
                    },
                    child: const Text('Сохранить'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

// ---------------------------------------------------------------------------
// Карточка для дашборда
// ---------------------------------------------------------------------------

class MetricsSummaryCard extends ConsumerWidget {
  const MetricsSummaryCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final metrics = ref.watch(customMetricsProvider);
    final logs = ref.watch(metricLogsProvider);
    final scheme = Theme.of(context).colorScheme;

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => GoRouter.of(context).go('/metrics'),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: metrics.isEmpty
              ? Row(
                  children: [
                    const Text('\u{1F4D0}', style: TextStyle(fontSize: 28)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Мои метрики: создай свой трекер — страницы, кофе, настроение…',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                    Icon(Icons.chevron_right, color: scheme.outline),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text('Мои метрики',
                            style: Theme.of(context).textTheme.titleSmall),
                        const Spacer(),
                        Icon(Icons.chevron_right,
                            size: 18, color: scheme.outline),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        for (final m in metrics.take(3))
                          Column(
                            children: [
                              AnimatedProgressRing(
                                progress: m.goal > 0
                                    ? (metricValueForPeriod(m, logs) /
                                            m.goal)
                                        .clamp(0.0, 1.0)
                                        .toDouble()
                                    : 0.0,
                                color: Color(m.color),
                                size: 54,
                                strokeWidth: 6,
                              ),
                              const SizedBox(height: 6),
                              SizedBox(
                                width: 80,
                                child: Text(
                                  m.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: Theme.of(context)
                                      .textTheme
                                      .labelSmall,
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
