import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/enums.dart';
import '../../models/finance.dart';
import '../../state/currency_state.dart';
import '../../state/providers.dart';
import '../../state/settings_state.dart';
import '../../widgets/viz/viz.dart';

/// «Индекс жизни» — единый балл дня из задач, привычек, воды, сна,
/// тренировок и финансовой дисциплины. Компоненты без данных
/// не участвуют в расчёте.
class LifeIndexCard extends ConsumerWidget {
  const LifeIndexCard({super.key});

  static String _dateStr(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  static double? _avg(List<double?> xs) {
    final v = [for (final x in xs) if (x != null) x];
    if (v.isEmpty) return null;
    return v.reduce((a, b) => a + b) / v.length;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final now = DateTime.now();
    final today = _dateStr(now);

    // --- Задачи на сегодня ---
    final tasks = ref.watch(tasksProvider);
    final dayTasks = tasks
        .where((t) => t.period == TaskPeriod.day && t.date == today)
        .toList();
    final double? taskScore = dayTasks.isEmpty
        ? null
        : dayTasks.where((t) => t.completed).length / dayTasks.length;

    // --- Привычки, актуальные сегодня ---
    final habits = ref.watch(habitsProvider);
    final habitLogs = ref.watch(habitLogsProvider);
    final weekStart = now.subtract(Duration(days: now.weekday - 1));
    final weekDates = [
      for (var i = 0; i < 7; i++) _dateStr(weekStart.add(Duration(days: i)))
    ];
    final habitScores = <double>[];
    for (final h in habits.where((h) => h.type == HabitTypeKind.good)) {
      bool doneOn(String date) => habitLogs.any((l) =>
          l.habitId == h.id &&
          l.date == date &&
          l.status == HabitLogStatus.done);
      final freq = h.frequency;
      if (freq != null && freq.type == HabitFrequencyType.times_per_week) {
        final target = freq.count ?? 7;
        if (target <= 0) continue;
        final done = weekDates.where(doneOn).length;
        habitScores.add((done / target).clamp(0.0, 1.0));
      } else if (freq != null &&
          freq.type == HabitFrequencyType.specific_days &&
          !(freq.days ?? const <int>[]).contains(now.weekday)) {
        continue; // сегодня не день этой привычки
      } else {
        habitScores.add(doneOn(today) ? 1.0 : 0.0);
      }
    }
    final double? habitScore = habitScores.isEmpty
        ? null
        : habitScores.reduce((a, b) => a + b) / habitScores.length;

    // --- Вода ---
    final waterLogs = ref.watch(waterLogsProvider);
    final waterGoal = ref.watch(waterGoalProvider);
    final drank = waterLogs
        .where((l) => l.date == today)
        .fold<num>(0, (s, l) => s + l.amount);
    final double? waterScore = waterGoal <= 0 || waterLogs.isEmpty
        ? null
        : (drank / waterGoal).clamp(0.0, 1.0).toDouble();

    // --- Сон (последняя ночь) ---
    final sleepLogs = ref.watch(sleepLogsProvider);
    final yesterday = _dateStr(now.subtract(const Duration(days: 1)));
    final recentSleep = sleepLogs
        .where((l) => l.date == today || l.date == yesterday)
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    final double? sleepScore = recentSleep.isEmpty
        ? null
        : (recentSleep.first.hours / 8.0).clamp(0.0, 1.0).toDouble();

    // --- Тренировки за 7 дней (цель — 3) ---
    final sessions = ref.watch(workoutSessionsProvider);
    final weekCutoff = _dateStr(now.subtract(const Duration(days: 6)));
    final weekSessions =
        sessions.where((s) => s.date.compareTo(weekCutoff) >= 0).length;
    final double? workoutScore = sessions.isEmpty
        ? null
        : (weekSessions / 3.0).clamp(0.0, 1.0).toDouble();

    // --- Финансовая дисциплина: траты сегодня vs средний день ---
    final transactions = ref.watch(transactionsProvider);
    final accounts = ref.watch(accountsProvider);
    final baseCurrency = ref.watch(defaultCurrencyProvider);
    final rates = ref.watch(currencyRatesProvider);
    num expenseFor(bool Function(String day) test) {
      num sum = 0;
      for (final t in transactions) {
        if (t.type != TransactionType.expense) continue;
        final d = t.date.length >= 10 ? t.date.substring(0, 10) : t.date;
        if (!test(d)) continue;
        Account? acc;
        for (final a in accounts) {
          if (a.id == t.accountId) {
            acc = a;
            break;
          }
        }
        sum += convertCurrency(
          amount: t.amount,
          from: acc?.currency ?? baseCurrency,
          to: baseCurrency,
          rates: rates,
        );
      }
      return sum;
    }

    final monthCutoff = _dateStr(now.subtract(const Duration(days: 30)));
    final last30 = expenseFor(
        (d) => d.compareTo(monthCutoff) >= 0 && d.compareTo(today) < 0);
    final avgDaily = last30 / 30;
    final spentToday = expenseFor((d) => d == today);
    double? financeScore;
    if (avgDaily > 0) {
      financeScore =
          spentToday <= avgDaily ? 1.0 : (avgDaily / spentToday).toDouble();
    }

    final components = <(String, IconData, double?, Color)>[
      ('Задачи', Icons.checklist, taskScore, const Color(0xFF3B82F6)),
      ('Привычки', Icons.event_repeat, habitScore, const Color(0xFF8B5CF6)),
      ('Вода', Icons.water_drop, waterScore, const Color(0xFF06B6D4)),
      ('Сон', Icons.nightlight_round, sleepScore, const Color(0xFF6366F1)),
      ('Тренировки', Icons.fitness_center, workoutScore,
          const Color(0xFF22C55E)),
      ('Финансы', Icons.account_balance_wallet, financeScore,
          const Color(0xFFF59E0B)),
    ];

    final active = [for (final c in components) if (c.$3 != null) c];
    final overall = _avg([for (final c in components) c.$3]);

    final bodyRing = _avg([waterScore, sleepScore, workoutScore]) ?? 0.0;
    final deedsRing = _avg([taskScore, habitScore]) ?? 0.0;
    final finRing = financeScore ?? 0.0;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.donut_large, size: 18, color: scheme.primary),
                const SizedBox(width: 8),
                Text('Индекс жизни',
                    style: Theme.of(context).textTheme.titleSmall),
                const Spacer(),
                Text('сегодня',
                    style: Theme.of(context)
                        .textTheme
                        .labelSmall
                        ?.copyWith(color: scheme.outline)),
              ],
            ),
            const SizedBox(height: 12),
            if (overall == null)
              Text(
                'Добавь задачи, привычки, воду или сон — и здесь появится единый балл дня.',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: scheme.outline),
              )
            else
              Row(
                children: [
                  ActivityRings(
                    size: 116,
                    strokeWidth: 11,
                    rings: [
                      ActivityRingData(
                          progress: deedsRing,
                          color: const Color(0xFF3B82F6)),
                      ActivityRingData(
                          progress: bodyRing, color: const Color(0xFF22C55E)),
                      ActivityRingData(
                          progress: finRing, color: const Color(0xFFF59E0B)),
                    ],
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '${(overall * 100).round()}',
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        Text('из 100',
                            style: Theme.of(context)
                                .textTheme
                                .labelSmall
                                ?.copyWith(color: scheme.outline)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      children: [
                        for (final c in active)
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(vertical: 2),
                            child: Row(
                              children: [
                                Icon(c.$2, size: 14, color: c.$4),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(c.$1,
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall),
                                ),
                                Text(
                                  '${((c.$3 ?? 0) * 100).round()}%',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.copyWith(
                                          fontWeight: FontWeight.w600),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
