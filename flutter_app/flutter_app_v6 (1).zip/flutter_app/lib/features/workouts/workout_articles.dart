import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../../models/article.dart';
import '../../services/photo_storage.dart';
import '../../state/providers.dart';
import '../../widgets/markdown/article_markdown.dart';

/// «Статьи» — полноценные Markdown-статьи внутри раздела тренировок:
/// программы, техника упражнений, ссылки, картинки и чек-листы.
class WorkoutArticlesTab extends ConsumerWidget {
  const WorkoutArticlesTab({super.key});

  String _snippet(String content) {
    var s = content.replaceAll(articleInlineImage, '');
    s = s.replaceAll(RegExp(r'[#>*`_~\[\]()-]'), ' ');
    s = s.replaceAll(RegExp(r'\s+'), ' ').trim();
    return s.length > 90 ? '${s.substring(0, 90)}…' : s;
  }

  Future<void> _create(BuildContext context, WidgetRef ref) async {
    final article = Article(
      id: const Uuid().v4(),
      createdAt: DateTime.now().toIso8601String(),
    );
    await ref.read(workoutArticlesProvider.notifier).add(article);
    if (context.mounted) {
      Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => WorkoutArticlePage(articleId: article.id),
      ));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final articles = [...ref.watch(workoutArticlesProvider)]..sort((a, b) {
        final ap = a.isPinned == true ? 0 : 1;
        final bp = b.isPinned == true ? 0 : 1;
        if (ap != bp) return ap - bp;
        return (b.updatedAt ?? b.createdAt)
            .compareTo(a.updatedAt ?? a.createdAt);
      });
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                'Статьи и знания',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.w700),
              ),
            ),
            FilledButton.tonalIcon(
              onPressed: () => _create(context, ref),
              icon: const Icon(Icons.add),
              label: const Text('Новая'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (articles.isEmpty)
          Container(
            width: double.infinity,
            padding:
                const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Icon(Icons.menu_book_outlined, color: scheme.outline),
                const SizedBox(height: 8),
                Text(
                  'Пока нет статей. Пишите программы, технику упражнений, '
                  'конспекты — с Markdown, ссылками, фото и чек-листами.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: scheme.outline),
                ),
              ],
            ),
          ),
        for (final a in articles)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Card(
              child: ListTile(
                leading: Icon(
                  a.isPinned == true
                      ? Icons.push_pin
                      : Icons.article_outlined,
                  color:
                      a.isPinned == true ? scheme.primary : scheme.outline,
                ),
                title: Text(
                  (a.title ?? '').isEmpty ? 'Без названия' : a.title!,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                subtitle: Text(
                  _snippet(a.content).isEmpty
                      ? _fmtDate(a.updatedAt ?? a.createdAt)
                      : '${_snippet(a.content)}\n${_fmtDate(a.updatedAt ?? a.createdAt)}',
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () =>
                    Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => WorkoutArticlePage(articleId: a.id),
                )),
              ),
            ),
          ),
      ],
    );
  }
}

String _fmtDate(String iso) {
  final dt = DateTime.tryParse(iso);
  if (dt == null) return '';
  return DateFormat('d MMM yyyy, HH:mm', 'ru').format(dt);
}

/// Полноэкранный редактор статьи: заголовок + Markdown-тело с пред-
/// просмотром, картинками, ссылками и интерактивными чек-боксами.
class WorkoutArticlePage extends ConsumerStatefulWidget {
  const WorkoutArticlePage({super.key, required this.articleId});

  final String articleId;

  @override
  ConsumerState<WorkoutArticlePage> createState() =>
      _WorkoutArticlePageState();
}

class _WorkoutArticlePageState extends ConsumerState<WorkoutArticlePage> {
  late final TextEditingController _title;
  late final TextEditingController _body;
  Timer? _debounce;
  bool _dirty = false;
  late bool _preview;

  Article? _current() => ref
      .read(workoutArticlesProvider)
      .cast<Article?>()
      .firstWhere((a) => a?.id == widget.articleId, orElse: () => null);

  @override
  void initState() {
    super.initState();
    final a = _current();
    _title = TextEditingController(text: a?.title ?? '');
    _body = TextEditingController(text: a?.content ?? '');
    _preview = (a?.content ?? '').trim().isNotEmpty ||
        (a?.title ?? '').trim().isNotEmpty;
    _title.addListener(_onChanged);
    _body.addListener(_onChanged);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  void _onChanged() {
    _dirty = true;
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), _flush);
  }

  void _flush() {
    if (!_dirty) return;
    _dirty = false;
    final t = _title.text.trim();
    ref.read(workoutArticlesProvider.notifier).update(
          widget.articleId,
          (a) => a.copyWith(
            title: t.isEmpty ? null : t,
            clearTitle: t.isEmpty,
            content: _body.text,
            updatedAt: DateTime.now().toIso8601String(),
          ),
        );
  }

  void _toggleTask(int lineIndex) {
    final next = toggleArticleTaskLine(_body.text, lineIndex);
    if (next == null) return;
    _body.text = next;
    _flush();
    setState(() {});
  }

  Future<String?> _pickImage() async {
    final path = await PhotoStorage.instance
        .pickAndStore(bucket: 'workout_photos', entityId: widget.articleId);
    if (path != null) {
      await ref.read(workoutArticlesProvider.notifier).update(
            widget.articleId,
            (a) => a.copyWith(photoUrls: [...?a.photoUrls, path]),
          );
    }
    return path;
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить статью?'),
        content:
            const Text('Статью и её картинки нельзя будет восстановить.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Удалить')),
        ],
      ),
    );
    if (ok != true) return;
    final a = _current();
    final files = <String>{
      ...?a?.photoUrls,
      if (a != null) ...articleLocalImages(a.content),
    };
    for (final p in files) {
      await PhotoStorage.instance.delete(p);
    }
    await ref
        .read(workoutArticlesProvider.notifier)
        .remove(widget.articleId);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final article = ref
        .watch(workoutArticlesProvider)
        .cast<Article?>()
        .firstWhere((a) => a?.id == widget.articleId, orElse: () => null);
    if (article == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('Статья не найдена')),
      );
    }
    final scheme = Theme.of(context).colorScheme;
    final created = _fmtDate(article.createdAt);
    final updated =
        article.updatedAt == null ? null : _fmtDate(article.updatedAt!);

    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, _) => _flush(),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Статья', style: TextStyle(fontSize: 16)),
          actions: [
            IconButton(
              tooltip: _preview ? 'Редактировать' : 'Просмотр',
              icon: Icon(_preview
                  ? Icons.edit_outlined
                  : Icons.visibility_outlined),
              onPressed: () {
                if (!_preview) _flush();
                setState(() => _preview = !_preview);
              },
            ),
            IconButton(
              tooltip:
                  article.isPinned == true ? 'Открепить' : 'Закрепить',
              icon: Icon(article.isPinned == true
                  ? Icons.push_pin
                  : Icons.push_pin_outlined),
              onPressed: () => ref
                  .read(workoutArticlesProvider.notifier)
                  .update(widget.articleId,
                      (a) => a.copyWith(isPinned: !(a.isPinned ?? false))),
            ),
            IconButton(
              tooltip: 'Удалить',
              icon: const Icon(Icons.delete_outline),
              onPressed: _delete,
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
          children: [
            TextField(
              controller: _title,
              textCapitalization: TextCapitalization.sentences,
              style: const TextStyle(
                  fontSize: 24, fontWeight: FontWeight.w800, height: 1.2),
              maxLines: null,
              decoration: const InputDecoration(
                hintText: 'Заголовок статьи',
                border: InputBorder.none,
                isCollapsed: true,
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Icon(Icons.schedule, size: 13, color: scheme.outline),
                const SizedBox(width: 5),
                Text(
                  updated == null ? created : '$created · изм. $updated',
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: scheme.outline),
                ),
              ],
            ),
            const Divider(height: 24),
            if (_preview)
              ArticleMarkdownView(
                text: _body.text,
                accent: scheme.primary,
                onToggleTask: _toggleTask,
              )
            else ...[
              ArticleMarkdownToolbar(
                controller: _body,
                onPickImage: _pickImage,
              ),
              const SizedBox(height: 6),
              TextField(
                controller: _body,
                textCapitalization: TextCapitalization.sentences,
                style: const TextStyle(fontSize: 16, height: 1.5),
                maxLines: null,
                minLines: 8,
                keyboardType: TextInputType.multiline,
                decoration: const InputDecoration(
                  hintText: 'Пишите статью… Markdown: ## заголовок, '
                      '**жирный**, - [ ] чек-пункт, [ссылка](url), '
                      '![картинка](url)',
                  border: InputBorder.none,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
