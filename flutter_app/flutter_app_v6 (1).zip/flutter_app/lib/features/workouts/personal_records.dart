import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/enums.dart';
import '../../models/misc.dart';
import '../../state/providers.dart';

/// Личные рекорды: автоматически считаются из журнала подходов:
/// макс. вес, макс. повторы и макс. объём (вес × повторы) по каждому
/// упражнению. Свежие рекорды (≤ 14 дней) подсвечиваются бейджем «PR!».

class ExercisePr {
  const ExercisePr({
    required this.exerciseId,
    required this.name,
    this.bestWeight,
    this.bestWeightDate,
    this.bestReps,
    this.bestRepsDate,
    this.bestVolume,
    this.bestVolumeDate,
    required this.lastPrDate,
  });

  final String exerciseId;
  final String name;
  final num? bestWeight;
  final String? bestWeightDate;
  final num? bestReps;
  final String? bestRepsDate;
  final num? bestVolume;
  final String? bestVolumeDate;

  /// Дата самого свежего из рекордов (для сортировки и бейджа).
  final String lastPrDate;

  bool get isFresh {
    final d = DateTime.tryParse(lastPrDate);
    if (d == null) return false;
    return DateTime.now().difference(d).inDays <= 14;
  }
}

List<ExercisePr> computePersonalRecords(
  List<ExerciseLog> logs,
  List<WorkoutNode> nodes,
) {
  final names = {
    for (final n in nodes)
      if (n.type == WorkoutNodeType.exercise) n.id: n.name,
  };
  final byExercise = <String, List<ExerciseLog>>{};
  for (final l in logs) {
    byExercise.putIfAbsent(l.exerciseId, () => []).add(l);
  }

  final out = <ExercisePr>[];
  byExercise.forEach((exId, list) {
    num? bw;
    String? bwDate;
    num? br;
    String? brDate;
    num? bv;
    String? bvDate;
    for (final l in list) {
      final w = l.metrics[WorkoutMetric.weight];
      final r = l.metrics[WorkoutMetric.reps];
      if (w != null && (bw == null || w > bw)) {
        bw = w;
        bwDate = l.date;
      }
      if (r != null && (br == null || r > br)) {
        br = r;
        brDate = l.date;
      }
      if (w != null && r != null) {
        final vol = w * r;
        if (bv == null || vol > bv) {
          bv = vol;
          bvDate = l.date;
        }
      }
    }
    if (bw == null && br == null && bv == null) return;
    final dates = [bwDate, brDate, bvDate].whereType<String>().toList()
      ..sort();
    out.add(ExercisePr(
      exerciseId: exId,
      name: names[exId] ?? 'Упражнение',
      bestWeight: bw,
      bestWeightDate: bwDate,
      bestReps: br,
      bestRepsDate: brDate,
      bestVolume: bv,
      bestVolumeDate: bvDate,
      lastPrDate: dates.isEmpty ? '' : dates.last,
    ));
  });
  out.sort((a, b) => b.lastPrDate.compareTo(a.lastPrDate));
  return out;
}

String _fmtNum(num v) =>
    v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(1);

String _fmtDate(String iso) {
  final d = DateTime.tryParse(iso);
  if (d == null) return iso;
  return '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}';
}

/// Секция «Личные рекорды» для вкладки Прогресс → Аналитика.
class PersonalRecordsSection extends ConsumerWidget {
  const PersonalRecordsSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final logs = ref.watch(exerciseLogsProvider);
    final nodes = ref.watch(workoutNodesProvider);
    final prs = computePersonalRecords(logs, nodes);
    final scheme = Theme.of(context).colorScheme;

    if (prs.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              const Text('\u{1F3C6}', style: TextStyle(fontSize: 24)),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Личные рекорды появятся здесь, как только ты запишешь первые подходы с весом и повторами.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text('\u{1F3C6}', style: TextStyle(fontSize: 18)),
                const SizedBox(width: 8),
                Text('Личные рекорды',
                    style: Theme.of(context).textTheme.titleSmall),
              ],
            ),
            const SizedBox(height: 10),
            for (final pr in prs.take(8)) ...[
              Row(
                children: [
                  Expanded(
                    child: Text(
                      pr.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                  if (pr.isFresh)
                    Container(
                      margin: const EdgeInsets.only(left: 6),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF59E0B)
                            .withValues(alpha: 0.18),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Text(
                        'PR!',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFFF59E0B),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: [
                  if (pr.bestWeight != null)
                    _PrChip(
                      icon: Icons.fitness_center,
                      label:
                          '${_fmtNum(pr.bestWeight!)} кг · ${_fmtDate(pr.bestWeightDate!)}',
                    ),
                  if (pr.bestReps != null)
                    _PrChip(
                      icon: Icons.repeat,
                      label:
                          '${_fmtNum(pr.bestReps!)} повт · ${_fmtDate(pr.bestRepsDate!)}',
                    ),
                  if (pr.bestVolume != null)
                    _PrChip(
                      icon: Icons.stacked_bar_chart,
                      label:
                          'объём ${_fmtNum(pr.bestVolume!)} · ${_fmtDate(pr.bestVolumeDate!)}',
                    ),
                ],
              ),
              if (pr != prs.take(8).last)
                Divider(height: 16, color: scheme.outlineVariant),
            ],
          ],
        ),
      ),
    );
  }
}

class _PrChip extends StatelessWidget {
  const _PrChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: scheme.outline),
          const SizedBox(width: 4),
          Text(label, style: Theme.of(context).textTheme.labelSmall),
        ],
      ),
    );
  }
}
