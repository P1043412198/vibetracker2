import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../models/enums.dart';
import '../models/task.dart';

/// Помощники для повторяющихся задач.
///
/// Формат правила [TaskItem.recurrence]:
/// - `daily` — каждый день;
/// - `weekly:1,3,5` — по ISO-дням недели (Пн=1..Вс=7);
/// - `monthly:15` — по числу месяца (в коротких месяцах —
///   последний день).

const _weekdayNames = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

List<int> _parseDays(String csv) => csv
    .split(',')
    .map((e) => int.tryParse(e.trim()))
    .whereType<int>()
    .where((d) => d >= 1 && d <= 7)
    .toList()
  ..sort();

/// Срабатывает ли правило [recurrence] в день [day].
bool recurrenceMatches(String recurrence, DateTime day) {
  if (recurrence == 'daily') return true;
  if (recurrence.startsWith('weekly:')) {
    return _parseDays(recurrence.substring(7)).contains(day.weekday);
  }
  if (recurrence.startsWith('monthly:')) {
    final dom = int.tryParse(recurrence.substring(8));
    if (dom == null || dom < 1) return false;
    final lastDay = DateTime(day.year, day.month + 1, 0).day;
    return day.day == (dom > lastDay ? lastDay : dom);
  }
  return false;
}

/// Человекочитаемая подпись правила для чипа на карточке.
String recurrenceLabel(String recurrence) {
  if (recurrence == 'daily') return 'Каждый день';
  if (recurrence.startsWith('weekly:')) {
    final days = _parseDays(recurrence.substring(7));
    if (days.isEmpty) return 'Повтор';
    return days.map((d) => _weekdayNames[d - 1]).join(', ');
  }
  if (recurrence.startsWith('monthly:')) {
    final dom = int.tryParse(recurrence.substring(8));
    return dom == null ? 'Повтор' : '$dom-го числа';
  }
  return 'Повтор';
}

/// Экземпляры повторяющихся задач, которых не хватает на [today].
/// Для каждой серии берётся последний экземпляр; если он в прошлом
/// и правило срабатывает сегодня — создаётся новая копия на сегодня
/// (чек-лист и прогресс сбрасываются).
List<TaskItem> missingRecurringInstances(
    List<TaskItem> tasks, DateTime today) {
  final todayStr = DateFormat('yyyy-MM-dd').format(today);
  final latestBySeries = <String, TaskItem>{};
  for (final t in tasks) {
    if (t.period != TaskPeriod.day) continue;
    if (t.recurrence == null && t.seriesId == null) continue;
    final sid = t.seriesId ?? t.id;
    final prev = latestBySeries[sid];
    if (prev == null || t.date.compareTo(prev.date) > 0) {
      latestBySeries[sid] = t;
    }
  }
  final result = <TaskItem>[];
  for (final entry in latestBySeries.entries) {
    final last = entry.value;
    final recurrence = last.recurrence;
    if (recurrence == null) continue; // серия остановлена
    if (last.date.compareTo(todayStr) >= 0) continue; // уже есть
    if (!recurrenceMatches(recurrence, today)) continue;
    result.add(TaskItem(
      id: const Uuid().v4(),
      title: last.title,
      period: TaskPeriod.day,
      date: todayStr,
      completed: false,
      failed: false,
      createdAt: DateTime.now().toIso8601String(),
      sphereId: last.sphereId,
      subtasks: last.subtasks
          ?.map((s) => Subtask(
              id: const Uuid().v4(), title: s.title, completed: false))
          .toList(),
      isPinned: last.isPinned,
      priority: last.priority,
      context: last.context,
      targetValue: last.targetValue,
      currentValue: last.targetValue == null ? null : 0.0,
      unit: last.unit,
      recurrence: recurrence,
      seriesId: entry.key,
    ));
  }
  return result;
}

/// Сколько последних экземпляров серии выполнено подряд.
/// Невыполненный СЕГОДНЯШНИЙ экземпляр серию не рвёт.
int recurringStreak(List<TaskItem> allTasks, TaskItem task) {
  final sid = task.seriesId ?? task.id;
  final chain = allTasks
      .where((t) =>
          t.period == TaskPeriod.day && (t.seriesId ?? t.id) == sid)
      .toList()
    ..sort((a, b) => b.date.compareTo(a.date));
  if (chain.isEmpty) return 0;
  var streak = 0;
  for (final t in chain) {
    if (t.completed) {
      streak++;
    } else if (identical(t, chain.first) || t.date == chain.first.date) {
      continue; // сегодняшняя ещё в работе
    } else {
      break;
    }
  }
  return streak;
}
