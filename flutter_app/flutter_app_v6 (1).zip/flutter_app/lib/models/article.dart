/// A standalone rich "article": Markdown body with links, images and
/// checkboxes. Stored as JSON via `JsonListController`.
class Article {
  Article({
    required this.id,
    required this.createdAt,
    this.title,
    this.content = '',
    this.updatedAt,
    this.isPinned,
    this.photoUrls,
  });

  final String id;
  final String? title;
  final String content;
  final String createdAt;
  final String? updatedAt;
  final bool? isPinned;

  /// Stored (relative) paths of photos embedded into [content], kept so the
  /// files can be cleaned up when the article is deleted.
  final List<String>? photoUrls;

  Article copyWith({
    String? title,
    String? content,
    String? updatedAt,
    bool? isPinned,
    List<String>? photoUrls,
    bool clearTitle = false,
  }) {
    return Article(
      id: id,
      createdAt: createdAt,
      title: clearTitle ? null : (title ?? this.title),
      content: content ?? this.content,
      updatedAt: updatedAt ?? this.updatedAt,
      isPinned: isPinned ?? this.isPinned,
      photoUrls: photoUrls ?? this.photoUrls,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt,
        if (title != null) 'title': title,
        'content': content,
        if (updatedAt != null) 'updatedAt': updatedAt,
        if (isPinned != null) 'isPinned': isPinned,
        if (photoUrls != null) 'photoUrls': photoUrls,
      };

  factory Article.fromJson(Map<String, dynamic> json) => Article(
        id: json['id'] as String,
        createdAt: json['createdAt'] as String? ?? '',
        title: json['title'] as String?,
        content: json['content'] as String? ?? '',
        updatedAt: json['updatedAt'] as String?,
        isPinned: json['isPinned'] as bool?,
        photoUrls: (json['photoUrls'] as List?)?.cast<String>(),
      );
}
