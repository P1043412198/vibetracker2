import 'enums.dart';

class Subtask {
  Subtask({required this.id, required this.title, required this.completed});

  final String id;
  final String title;
  final bool completed;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'completed': completed,
      };

  factory Subtask.fromJson(Map<String, dynamic> json) => Subtask(
        id: json['id'] as String,
        title: json['title'] as String,
        completed: (json['completed'] ?? false) as bool,
      );
}

class TaskItem {
  TaskItem({
    required this.id,
    required this.title,
    required this.period,
    required this.date,
    required this.completed,
    required this.failed,
    required this.createdAt,
    this.sphereId,
    this.subtasks,
    this.order,
    this.isPinned,
    this.priority,
    this.context,
    this.reminderAt,
    this.targetValue,
    this.currentValue,
    this.unit,
    this.recurrence,
    this.seriesId,
  });

  final String id;
  final String title;
  final String? sphereId;
  final TaskPeriod period;
  final String date;
  final bool completed;
  final bool failed;
  final String createdAt;
  final List<Subtask>? subtasks;
  final int? order;
  final bool? isPinned;
  final TaskPriority? priority;
  final String? context;

  /// Optional ISO-8601 datetime to fire a one-shot reminder for this task.
  final String? reminderAt;

  /// Измеримое отслеживание: задача считается к [targetValue]
  /// (страницы, км, повторы…). [currentValue] обновляется с карточки
  /// задачи, [unit] — подпись единицы («стр», «км», «шт»).
  final double? targetValue;
  final double? currentValue;
  final String? unit;

  /// Правило повторения: 'daily' | 'weekly:1,3,5' | 'monthly:15'.
  /// См. lib/services/task_recurrence.dart. Null — разовая задача.
  final String? recurrence;

  /// Общий id цепочки повторов (все экземпляры серии делят его).
  final String? seriesId;

  TaskItem copyWith({
    String? title,
    String? sphereId,
    TaskPeriod? period,
    String? date,
    bool? completed,
    bool? failed,
    List<Subtask>? subtasks,
    int? order,
    bool? isPinned,
    TaskPriority? priority,
    String? context,
    String? reminderAt,
    double? targetValue,
    double? currentValue,
    String? unit,
    String? recurrence,
    String? seriesId,
    bool clearPriority = false,
    bool clearContext = false,
    bool clearReminder = false,
    bool clearTracking = false,
    bool clearRecurrence = false,
  }) {
    return TaskItem(
      id: id,
      title: title ?? this.title,
      sphereId: sphereId ?? this.sphereId,
      period: period ?? this.period,
      date: date ?? this.date,
      completed: completed ?? this.completed,
      failed: failed ?? this.failed,
      createdAt: createdAt,
      subtasks: subtasks ?? this.subtasks,
      order: order ?? this.order,
      isPinned: isPinned ?? this.isPinned,
      priority: clearPriority ? null : (priority ?? this.priority),
      context: clearContext ? null : (context ?? this.context),
      reminderAt: clearReminder ? null : (reminderAt ?? this.reminderAt),
      targetValue: clearTracking ? null : (targetValue ?? this.targetValue),
      currentValue:
          clearTracking ? null : (currentValue ?? this.currentValue),
      unit: clearTracking ? null : (unit ?? this.unit),
      recurrence: clearRecurrence ? null : (recurrence ?? this.recurrence),
      seriesId: seriesId ?? this.seriesId,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        if (sphereId != null) 'sphereId': sphereId,
        'period': period.name,
        'date': date,
        'completed': completed,
        'failed': failed,
        'createdAt': createdAt,
        if (subtasks != null)
          'subtasks': subtasks!.map((e) => e.toJson()).toList(),
        if (order != null) 'order': order,
        if (isPinned != null) 'isPinned': isPinned,
        if (priority != null) 'priority': priority!.name,
        if (context != null) 'context': context,
        if (reminderAt != null) 'reminderAt': reminderAt,
        if (targetValue != null) 'targetValue': targetValue,
        if (currentValue != null) 'currentValue': currentValue,
        if (unit != null) 'unit': unit,
        if (recurrence != null) 'recurrence': recurrence,
        if (seriesId != null) 'seriesId': seriesId,
      };

  factory TaskItem.fromJson(Map<String, dynamic> json) => TaskItem(
        id: json['id'] as String,
        title: json['title'] as String,
        sphereId: json['sphereId'] as String?,
        period: enumFromName(
            TaskPeriod.values, json['period'] as String?, TaskPeriod.day),
        date: json['date'] as String,
        completed: (json['completed'] ?? false) as bool,
        failed: (json['failed'] ?? false) as bool,
        createdAt: json['createdAt'] as String,
        subtasks: (json['subtasks'] as List?)
            ?.whereType<Map>()
            .map((e) =>
                Subtask.fromJson(e.map((k, v) => MapEntry(k.toString(), v))))
            .toList(),
        order: (json['order'] as num?)?.toInt(),
        isPinned: json['isPinned'] as bool?,
        priority: json['priority'] != null
            ? enumFromName(TaskPriority.values, json['priority'] as String?,
                TaskPriority.later)
            : null,
        context: json['context'] as String?,
        reminderAt: json['reminderAt'] as String?,
        targetValue: (json['targetValue'] as num?)?.toDouble(),
        currentValue: (json['currentValue'] as num?)?.toDouble(),
        unit: json['unit'] as String?,
        recurrence: json['recurrence'] as String?,
        seriesId: json['seriesId'] as String?,
      );
}
