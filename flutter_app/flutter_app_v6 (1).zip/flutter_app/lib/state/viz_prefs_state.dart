import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/storage.dart';

/// Persisted per-block visualisation style preferences.
///
/// Key = a stable block identifier (e.g. `water.header`, `goals.card`,
/// `tasks.progress`), value = a `VizStyle.name`. Users pick how each metric
/// is rendered via the style picker in `ConfigurableViz`; the choice is
/// stored here and survives restarts.
class VizPrefsController extends StateNotifier<Map<String, String>> {
  VizPrefsController() : super(const {}) {
    final raw = AppStorage.readString(_key);
    if (raw != null && raw.isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map) {
          state = decoded.map(
            (k, v) => MapEntry(k.toString(), v.toString()),
          );
        }
      } catch (_) {
        // Corrupt prefs are simply reset to defaults.
      }
    }
  }

  static const _key = 'vizStylePrefs';

  Future<void> setStyle(String prefKey, String styleName) async {
    state = {...state, prefKey: styleName};
    await AppStorage.writeString(_key, jsonEncode(state));
  }
}

final vizPrefsProvider =
    StateNotifierProvider<VizPrefsController, Map<String, String>>((ref) {
  return VizPrefsController();
});
