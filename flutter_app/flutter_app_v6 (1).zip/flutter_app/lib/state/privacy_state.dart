import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/storage.dart';

/// Режим приватности: отмеченные задачи/привычки/цели показываются
/// как «••••••», пока не нажат значок глаза. Список приватных id
/// хранится в Hive, а само раскрытие действует только до перезапуска
/// приложения (при старте всегда скрыто).

const kCensorPlaceholder = '••••••';

class PrivateIdsController extends StateNotifier<Set<String>> {
  PrivateIdsController() : super(const {}) {
    final raw = AppStorage.readString(_key);
    if (raw != null && raw.isNotEmpty) {
      try {
        final list = json.decode(raw);
        if (list is List) {
          state = {for (final e in list) e.toString()};
        }
      } catch (_) {}
    }
  }

  static const _key = 'privateItemIds';

  Future<void> _persist() =>
      AppStorage.writeString(_key, json.encode(state.toList()));

  void toggle(String id) {
    state = state.contains(id)
        ? {for (final e in state) if (e != id) e}
        : {...state, id};
    _persist();
  }
}

/// id элементов (задач, привычек, целей), названия которых скрыты.
final privateIdsProvider =
    StateNotifierProvider<PrivateIdsController, Set<String>>(
        (ref) => PrivateIdsController());

/// Сеансовое раскрытие: true — показывать настоящие названия.
/// Нарочно НЕ сохраняется: после перезапуска всё снова скрыто.
final privacyRevealedProvider = StateProvider<bool>((ref) => false);

/// true, если название элемента сейчас нужно цензурировать.
bool isCensored(WidgetRef ref, String id) =>
    ref.watch(privateIdsProvider).contains(id) &&
    !ref.watch(privacyRevealedProvider);

/// Текст, который сам прячет себя, если элемент помечен приватным
/// и глаз не нажат. Подходит для списков и виджетов дашборда.
class PrivacyText extends ConsumerWidget {
  const PrivacyText(
    this.itemId,
    this.text, {
    super.key,
    this.style,
    this.maxLines,
    this.overflow,
    this.textAlign,
  });

  final String itemId;
  final String text;
  final TextStyle? style;
  final int? maxLines;
  final TextOverflow? overflow;
  final TextAlign? textAlign;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final censored = isCensored(ref, itemId);
    return Text(
      censored ? kCensorPlaceholder : text,
      style: style,
      maxLines: maxLines,
      overflow: overflow,
      textAlign: textAlign,
    );
  }
}

/// Кнопка-глаз для AppBar: временно показать/скрыть приватные названия.
class PrivacyEyeButton extends ConsumerWidget {
  const PrivacyEyeButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hasPrivate = ref.watch(privateIdsProvider).isNotEmpty;
    final revealed = ref.watch(privacyRevealedProvider);
    if (!hasPrivate) return const SizedBox.shrink();
    return IconButton(
      tooltip: revealed ? 'Скрыть приватные' : 'Показать приватные',
      icon: Icon(
          revealed ? Icons.visibility : Icons.visibility_off_outlined),
      onPressed: () =>
          ref.read(privacyRevealedProvider.notifier).state = !revealed,
    );
  }
}
